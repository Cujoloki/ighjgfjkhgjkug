import React from 'react';
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormDescription, FormMessage } from './Form';
import { Input } from './Input';
import { Button } from './Button';
import { Skeleton } from './Skeleton';
import { type FarmSetting } from '../endpoints/farm-settings_GET.schema';
import styles from './FarmSettingsForm.module.css';

interface FarmSettingsFormProps {
  settings: FarmSetting[];
  onSubmit: (data: Record<string, string>) => void;
  isSubmitting: boolean;
  className?: string;
}

const createFormSchema = (settings: FarmSetting[]) => {
  const shape: Record<string, z.ZodTypeAny> = {};
  settings.forEach(setting => {
    let validator: z.ZodTypeAny = z.string().min(1, { message: 'This field is required.' });
    if (setting.settingType === 'number') {
      validator = z.string()
        .refine(val => !isNaN(parseFloat(val)), { message: 'Must be a valid number.' })
        .refine(val => parseFloat(val) >= 0, { message: 'Must be a non-negative number.' });
    }
    shape[setting.settingKey] = validator;
  });
  return z.object(shape);
};

export const FarmSettingsFormSkeleton = () => (
  <div className={styles.formContainer}>
    {[...Array(4)].map((_, i) => (
      <div key={i} className={styles.skeletonItem}>
        <Skeleton style={{ height: '1.25rem', width: '150px', marginBottom: 'var(--spacing-2)' }} />
        <Skeleton style={{ height: '2.5rem', width: '100%' }} />
        <Skeleton style={{ height: '1rem', width: '250px', marginTop: 'var(--spacing-1)' }} />
      </div>
    ))}
    <Skeleton style={{ height: '2.5rem', width: '120px', marginTop: 'var(--spacing-4)' }} />
  </div>
);

export const FarmSettingsForm = ({ settings, onSubmit, isSubmitting, className }: FarmSettingsFormProps) => {
  const formSchema = React.useMemo(() => createFormSchema(settings), [settings]);
  
  const defaultValues = React.useMemo(() => {
    return settings.reduce((acc, setting) => {
      acc[setting.settingKey] = String(setting.settingValue);
      return acc;
    }, {} as Record<string, string>);
  }, [settings]);

  const form = useForm({
    schema: formSchema,
    defaultValues,
  });

  const handleFormSubmit = (values: z.infer<typeof formSchema>) => {
    onSubmit(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className={`${styles.formContainer} ${className ?? ''}`}>
        {settings.map((setting) => (
          <FormItem key={setting.settingKey} name={setting.settingKey}>
            <FormLabel>{setting.settingKey.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</FormLabel>
            <FormControl>
              <Input
                type={setting.settingType === 'number' ? 'number' : 'text'}
                value={form.values[setting.settingKey] || ''}
                onChange={(e) =>
                  form.setValues((prev) => ({ ...prev, [setting.settingKey]: e.target.value }))
                }
                placeholder={`Enter value for ${setting.settingKey}`}
              />
            </FormControl>
            {setting.description && <FormDescription>{setting.description}</FormDescription>}
            <FormMessage />
          </FormItem>
        ))}
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : 'Save Settings'}
        </Button>
      </form>
    </Form>
  );
};