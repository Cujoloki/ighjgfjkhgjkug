import React, { useEffect } from 'react';
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage } from './Form';
import { Input } from './Input';
import { Textarea } from './Textarea';
import { Button } from './Button';
import { schema as createPlotSchema } from '../endpoints/plots_POST.schema';
import { schema as updatePlotSchema } from '../endpoints/plots/update_POST.schema';
import type { PlotWithRows } from '../endpoints/plots_GET.schema';
import styles from './PlotManagementForm.module.css';

const PLOT_COLORS = [
  '#84cc16', '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9',
  '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899'
];

interface PlotManagementFormProps {
  plot?: PlotWithRows | null;
  onSubmit: (values: z.infer<typeof createPlotSchema> | z.infer<typeof updatePlotSchema>) => void;
  onCancel: () => void;
  isSubmitting: boolean;
  className?: string;
}

export function PlotManagementForm({ plot, onSubmit, onCancel, isSubmitting, className }: PlotManagementFormProps) {
  const isEditMode = !!plot;
  const formSchema = isEditMode ? updatePlotSchema : createPlotSchema;

  const form = useForm({
    schema: formSchema,
    defaultValues: {
      id: plot?.id,
      name: plot?.name ?? '',
      description: plot?.description ?? '',
      color: plot?.color ?? PLOT_COLORS[0],
    },
  });

  useEffect(() => {
    form.setValues({
      id: plot?.id,
      name: plot?.name ?? '',
      description: plot?.description ?? '',
      color: plot?.color ?? PLOT_COLORS[0],
    });
  }, [plot, form.setValues]);

  const handleColorSelect = (color: string) => {
    form.setValues(prev => ({ ...prev, color }));
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={`${styles.form} ${className || ''}`}>
        <FormItem name="name">
          <FormLabel>Plot Name</FormLabel>
          <FormControl>
            <Input
              placeholder="e.g., North Field, High Tunnel 1"
              value={form.values.name}
              onChange={(e) => form.setValues(prev => ({ ...prev, name: e.target.value }))}
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="description">
          <FormLabel>Description</FormLabel>
          <FormControl>
            <Textarea
              placeholder="Optional: Add notes about this plot"
              value={form.values.description ?? ''}
              onChange={(e) => form.setValues(prev => ({ ...prev, description: e.target.value }))}
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="color">
          <FormLabel>Plot Color</FormLabel>
          <div className={styles.colorPicker}>
            {PLOT_COLORS.map(c => (
              <button
                key={c}
                type="button"
                className={styles.colorSwatch}
                style={{ backgroundColor: c }}
                data-selected={form.values.color === c}
                onClick={() => handleColorSelect(c)}
                aria-label={`Select color ${c}`}
              />
            ))}
          </div>
          <FormMessage />
        </FormItem>

        <div className={styles.formActions}>
          <Button type="button" variant="ghost" onClick={onCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (isEditMode ? 'Saving...' : 'Creating...') : (isEditMode ? 'Save Changes' : 'Create Plot')}
          </Button>
        </div>
      </form>
    </Form>
  );
}