import React from 'react';
import { RowCreateForm } from './RowCreateForm';
import { RowEditForm } from './RowEditForm';
import styles from './RowManagementForm.module.css';
import { RowWithPlanting } from '../endpoints/rows_GET.schema';

type RowManagementFormProps = {
  row?: RowWithPlanting | null;
  onClose: () => void;
};

export function RowManagementForm({ row, onClose }: RowManagementFormProps) {
  const isEditMode = !!row;

  return (
    <div className={styles.formContainer}>
      <h3>{isEditMode ? `Edit Row ${row!.rowNumber}` : 'Add New Row(s)'}</h3>
      <div className={styles.form}>
        {isEditMode ? (
          <RowEditForm row={row!} onClose={onClose} />
        ) : (
          <RowCreateForm onClose={onClose} />
        )}
      </div>
    </div>
  );
}