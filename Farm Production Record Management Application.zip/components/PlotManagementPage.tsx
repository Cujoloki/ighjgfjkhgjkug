import React, { useState, useMemo } from 'react';
import { useGetPlots, usePostPlot, useUpdatePlot, useDeletePlot } from '../helpers/plotQueries';
import { PlotCard } from './PlotCard';
import { Button } from './Button';
import { PlotManagementForm } from './PlotManagementForm';
import { PlotRowAssignment } from './PlotRowAssignment';
import { Skeleton } from './Skeleton';
import { Plus, AlertTriangle } from 'lucide-react';
import styles from './PlotManagementPage.module.css';
import type { PlotWithRows } from '../endpoints/plots_GET.schema';

type ModalState = 
  | { view: 'closed' }
  | { view: 'form'; plot: PlotWithRows | null }
  | { view: 'assign'; plot: PlotWithRows }
  | { view: 'delete'; plot: PlotWithRows };

export function PlotManagementPage({ className }: { className?: string }) {
  const [modalState, setModalState] = useState<ModalState>({ view: 'closed' });

  const { data: plots, isLoading, isError, error } = useGetPlots();
  const createPlotMutation = usePostPlot();
  const updatePlotMutation = useUpdatePlot();
  const deletePlotMutation = useDeletePlot();

  const isSubmitting = createPlotMutation.isPending || updatePlotMutation.isPending;

  const handleFormSubmit = (values: any) => {
    if (values.id) {
      updatePlotMutation.mutate(values, {
        onSuccess: () => setModalState({ view: 'closed' }),
      });
    } else {
      createPlotMutation.mutate(values, {
        onSuccess: () => setModalState({ view: 'closed' }),
      });
    }
  };

  const handleDeleteConfirm = () => {
    if (modalState.view === 'delete') {
      deletePlotMutation.mutate({ id: modalState.plot.id }, {
        onSuccess: () => setModalState({ view: 'closed' }),
      });
    }
  };

  const unassignedRows = useMemo(() => {
    // This logic would be more robust if we also fetched all rows.
    // For now, we assume this page is primarily for plot management.
    return [];
  }, []);

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className={styles.grid}>
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className={styles.skeletonCard}>
              <Skeleton style={{ height: '2rem', width: '60%', marginBottom: 'var(--spacing-2)' }} />
              <Skeleton style={{ height: '1rem', width: '80%' }} />
              <Skeleton style={{ height: '1rem', width: '40%', marginTop: 'var(--spacing-4)' }} />
            </div>
          ))}
        </div>
      );
    }

    if (isError) {
      return (
        <div className={styles.errorState}>
          <AlertTriangle size={48} />
          <h3>Error loading plots</h3>
          <p>{error.message}</p>
        </div>
      );
    }

    if (!plots || plots.length === 0) {
      return (
        <div className={styles.emptyState}>
          <h2>No Plots Created Yet</h2>
          <p>Group your farm rows into plots for better organization.</p>
          <Button onClick={() => setModalState({ view: 'form', plot: null })}>
            <Plus size={16} /> Create Your First Plot
          </Button>
        </div>
      );
    }

    return (
      <div className={styles.grid}>
        {plots.map(plot => (
          <PlotCard
            key={plot.id}
            plot={plot}
            onEdit={() => setModalState({ view: 'form', plot })}
            onAssignRows={() => setModalState({ view: 'assign', plot })}
            onDelete={() => setModalState({ view: 'delete', plot })}
          />
        ))}
      </div>
    );
  };

  return (
    <div className={`${styles.page} ${className || ''}`}>
      <header className={styles.header}>
        <h1>Plot Management</h1>
        <Button onClick={() => setModalState({ view: 'form', plot: null })}>
          <Plus size={16} /> New Plot
        </Button>
      </header>
      
      <main className={styles.content}>
        {renderContent()}
      </main>

      {/* Modals would typically be implemented with a proper Dialog component */}
      {modalState.view === 'form' && (
        <div className={styles.modalBackdrop}>
          <div className={styles.modalContent}>
            <h2>{modalState.plot ? 'Edit Plot' : 'Create New Plot'}</h2>
            <PlotManagementForm
              plot={modalState.plot}
              onSubmit={handleFormSubmit}
              onCancel={() => setModalState({ view: 'closed' })}
              isSubmitting={isSubmitting}
            />
          </div>
        </div>
      )}

      {modalState.view === 'assign' && (
        <div className={styles.modalBackdrop}>
          <div className={styles.modalContent}>
            <h2>Assign Rows to "{modalState.plot.name}"</h2>
            <PlotRowAssignment
              plot={modalState.plot}
              onClose={() => setModalState({ view: 'closed' })}
            />
          </div>
        </div>
      )}

      {modalState.view === 'delete' && (
        <div className={styles.modalBackdrop}>
          <div className={styles.modalContent}>
            <h2>Confirm Deletion</h2>
            <p>Are you sure you want to delete the plot "<strong>{modalState.plot.name}</strong>"? This action cannot be undone.</p>
            <div className={styles.deleteActions}>
              <Button variant="ghost" onClick={() => setModalState({ view: 'closed' })} disabled={deletePlotMutation.isPending}>Cancel</Button>
              <Button variant="destructive" onClick={handleDeleteConfirm} disabled={deletePlotMutation.isPending}>
                {deletePlotMutation.isPending ? 'Deleting...' : 'Delete Plot'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}