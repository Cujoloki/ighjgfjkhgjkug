import React from 'react';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from './Chart';
import { Skeleton } from './Skeleton';
import type { WeeklySummary } from '../endpoints/weekly-harvest-summary_GET.schema';
import styles from './WeeklyHarvestSummary.module.css';

const chartConfig = {
  totalValue: {
    label: 'Weekly Revenue',
    color: 'var(--primary)',
  },
} satisfies ChartConfig;

const WeeklyHarvestSummarySkeleton = () => (
  <div className={styles.container}>
    <div className={styles.header}>
      <Skeleton style={{ height: '1.75rem', width: '200px' }} />
      <Skeleton style={{ height: '1rem', width: '250px' }} />
    </div>
    <div className={styles.chartContainer}>
      <Skeleton style={{ height: '100%', width: '100%' }} />
    </div>
    <div className={styles.stats}>
      <div className={styles.statItem}>
        <Skeleton style={{ height: '1rem', width: '100px' }} />
        <Skeleton style={{ height: '1.5rem', width: '80px' }} />
      </div>
      <div className={styles.statItem}>
        <Skeleton style={{ height: '1rem', width: '120px' }} />
        <Skeleton style={{ height: '1.5rem', width: '100px' }} />
      </div>
    </div>
  </div>
);

interface WeeklyHarvestSummaryProps {
  data: WeeklySummary[];
  isLoading: boolean;
  className?: string;
}

export const WeeklyHarvestSummary = ({ data, isLoading, className }: WeeklyHarvestSummaryProps) => {
  if (isLoading) {
    return <WeeklyHarvestSummarySkeleton />;
  }

  if (!data || data.length === 0) {
    return (
      <div className={`${styles.container} ${styles.emptyState} ${className ?? ''}`}>
        <p>No weekly harvest data available yet.</p>
      </div>
    );
  }

  const chartData = data.map(week => ({
    date: new Date(week.weekStartDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    totalValue: week.totalValue,
  }));

  const latestWeek = data[data.length - 1];

  return (
    <div className={`${styles.container} ${className ?? ''}`}>
      <div className={styles.header}>
        <h3 className={styles.title}>Weekly Harvest Summary</h3>
        <p className={styles.subtitle}>Revenue trends from weekly harvests.</p>
      </div>
      <div className={styles.chartContainer}>
        <ChartContainer config={chartConfig}>
          <BarChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              tickFormatter={(value) => value.slice(0, 6)}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              tickFormatter={(value) => `$${Number(value) / 1000}k`}
            />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dot" />}
            />
            <Bar dataKey="totalValue" fill="var(--color-totalValue)" radius={4} />
          </BarChart>
        </ChartContainer>
      </div>
      <div className={styles.stats}>
        <div className={styles.statItem}>
          <span className={styles.statLabel}>Latest Week's Value</span>
          <span className={styles.statValue}>
            ${latestWeek.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        <div className={styles.statItem}>
          <span className={styles.statLabel}>Latest Week's Pounds</span>
          <span className={styles.statValue}>
            {latestWeek.totalPounds.toLocaleString()} lbs
          </span>
        </div>
      </div>
    </div>
  );
};