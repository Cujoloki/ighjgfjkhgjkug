import React, { useState, useMemo, useRef, useEffect } from 'react';

// Web Speech API type declarations
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: ((event: Event) => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: ((event: Event) => void) | null;
}

interface SpeechRecognitionStatic {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}
import * as z from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from './Form';
import { useGetCrops, useGetRows, useGetPlantings, usePostPlanting } from '../helpers/farmQueries';
import { canPlantCropInRow, getRotationStatus } from '../helpers/cropRotation';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './Select';
import { Popover, PopoverContent, PopoverTrigger } from './Popover';
import { Button } from './Button';
import { Calendar as CalendarIcon, CheckCircle, AlertTriangle, XCircle, Loader2, Mic, MicOff, Square } from 'lucide-react';
import { Calendar } from './Calendar';
import { Textarea } from './Textarea';
import { Skeleton } from './Skeleton';
import { toast } from 'sonner';
import styles from './PlantNewCropForm.module.css';

const plantingSchema = z.object({
  cropId: z.string().min(1, 'Please select a crop.'),
  rowId: z.string().min(1, 'Please select a row.'),
  plantedDate: z.date({ required_error: 'Please select a planting date.' }),
  notes: z.string().optional(),
});

type PlantingFormValues = z.infer<typeof plantingSchema>;

type SpeechRecognitionState = 'idle' | 'listening' | 'processing';

export const PlantNewCropForm = () => {
  const { data: crops, isFetching: isCropsLoading } = useGetCrops();
  const { data: rows, isFetching: isRowsLoading } = useGetRows();
  const { data: plantings, isFetching: isPlantingsLoading } = useGetPlantings();
  const postPlanting = usePostPlanting();

  const [speechState, setSpeechState] = useState<SpeechRecognitionState>('idle');
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const form = useForm({
    schema: plantingSchema,
    defaultValues: {
      cropId: '',
      rowId: '',
      notes: '',
    },
  });

  const { cropId: selectedCropId, rowId: selectedRowId } = form.values;

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        setSpeechState('listening');
        toast.info('Listening...', { duration: 2000 });
      };

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        console.log('Speech recognition result:', transcript);
        handleNotesTranscript(transcript);
        setSpeechState('idle');
        toast.success('Speech recognized successfully!');
      };

      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setSpeechState('idle');
        
        let errorMessage = 'Speech recognition failed';
        switch (event.error) {
          case 'no-speech':
            errorMessage = 'No speech detected. Please try again.';
            break;
          case 'not-allowed':
            errorMessage = 'Microphone access denied. Please allow microphone access.';
            break;
          case 'network':
            errorMessage = 'Network error. Please check your connection.';
            break;
          default:
            errorMessage = `Speech recognition error: ${event.error}`;
        }
        toast.error(errorMessage);
      };

      recognitionRef.current.onend = () => {
        if (speechState === 'listening') {
          setSpeechState('idle');
        }
      };
    }
  }, [speechState]);

  const availableRows = useMemo(() => {
    return rows?.filter(row => !row.currentPlanting) ?? [];
  }, [rows]);

  const rotationValidation = useMemo(() => {
    if (!plantings || !selectedCropId || !selectedRowId) {
      return { canPlant: true };
    }
    return canPlantCropInRow(plantings, parseInt(selectedRowId, 10), parseInt(selectedCropId, 10));
  }, [plantings, selectedCropId, selectedRowId]);

  const handleNotesTranscript = (transcript: string) => {
    const currentNotes = form.values.notes || '';
    const newNotes = currentNotes ? `${currentNotes} ${transcript}` : transcript;
    form.setValues(prev => ({ ...prev, notes: newNotes }));
  };

  const startSpeechRecognition = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition is not supported in this browser.');
      return;
    }

    if (speechState === 'listening') {
      stopSpeechRecognition();
      return;
    }

    setSpeechState('listening');
    try {
      recognitionRef.current.start();
    } catch (error) {
      console.error('Failed to start speech recognition:', error);
      setSpeechState('idle');
      toast.error('Failed to start speech recognition');
    }
  };

  const stopSpeechRecognition = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setSpeechState('idle');
  };

  const getSpeechButtonIcon = () => {
    if (speechState === 'listening') {
      return <Square size={16} className={styles.recordingIcon} />;
    }
    return speechState === 'idle' ? <Mic size={16} /> : <MicOff size={16} />;
  };

  const getSpeechButtonVariant = () => {
    if (speechState === 'listening') {
      return 'destructive' as const;
    }
    return 'outline' as const;
  };

  const isSpeechSupported = typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);

  const onSubmit = (values: PlantingFormValues) => {
    if (!rotationValidation.canPlant) {
      form.setFieldError('rowId', rotationValidation.reason ?? 'This crop cannot be planted in this row due to rotation rules.');
      return;
    }

    postPlanting.mutate({
      cropId: parseInt(values.cropId, 10),
      rowId: parseInt(values.rowId, 10),
      plantedDate: values.plantedDate,
      notes: values.notes,
    }, {
      onSuccess: () => {
        toast.success('New crop planted successfully!');
        form.setValues(prev => ({ ...prev, cropId: '', rowId: '', notes: '' }));
      },
      onError: (error) => {
        if (error instanceof Error) {
          toast.error(`Failed to plant crop: ${error.message}`);
        } else {
          toast.error('An unknown error occurred.');
        }
      }
    });
  };

  if (isCropsLoading || isRowsLoading || isPlantingsLoading) {
    return <PlantNewCropFormSkeleton />;
  }

  return (
    <>
      {isSpeechSupported && (
        <div className={styles.speechHint}>
          💬 Use the microphone button to speak your planting notes
        </div>
      )}
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={styles.form}>
        <div className={styles.grid}>
          <FormItem name="cropId">
            <FormLabel>Crop</FormLabel>
            <Select
              value={form.values.cropId}
              onValueChange={(value) => form.setValues(prev => ({ ...prev, cropId: value }))}
            >
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Select a crop to plant" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {crops?.map(crop => (
                  <SelectItem key={crop.id} value={String(crop.id)}>
                    {crop.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>

          <FormItem name="rowId">
            <FormLabel>Row</FormLabel>
            <Select
              value={form.values.rowId}
              onValueChange={(value) => form.setValues(prev => ({ ...prev, rowId: value }))}
              disabled={!selectedCropId}
            >
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Select an available row" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {availableRows.map(row => {
                  const status = selectedCropId && plantings ? getRotationStatus(plantings, row.id, parseInt(selectedCropId, 10)) : 'ok';
                  return (
                    <SelectItem key={row.id} value={String(row.id)} disabled={status === 'blocked'}>
                      <div className={styles.rowItem}>
                        <span>Row {row.rowNumber} ({row.rowLength} ft)</span>
                        {status === 'ok' && <CheckCircle className={styles.iconOk} />}
                        {status === 'warning' && <AlertTriangle className={styles.iconWarning} />}
                        {status === 'blocked' && <XCircle className={styles.iconBlocked} />}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            {!rotationValidation.canPlant && (
              <p className={styles.rotationError}>{rotationValidation.reason}</p>
            )}
            <FormMessage />
          </FormItem>
        </div>

        <FormItem name="plantedDate">
          <FormLabel>Planted Date</FormLabel>
          <Popover>
            <PopoverTrigger asChild>
              <FormControl>
                <Button variant="outline" className={styles.dateButton}>
                  {form.values.plantedDate ? form.values.plantedDate.toLocaleDateString() : <span>Pick a date</span>}
                  <CalendarIcon className={styles.calendarIcon} />
                </Button>
              </FormControl>
            </PopoverTrigger>
            <PopoverContent removeBackgroundAndPadding>
              <Calendar
                mode="single"
                selected={form.values.plantedDate}
                onSelect={(date) => form.setValues(prev => ({ ...prev, plantedDate: date as Date }))}
                disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
              />
            </PopoverContent>
          </Popover>
          <FormMessage />
        </FormItem>

        <FormItem name="notes">
          <FormLabel>Notes (Optional)</FormLabel>
          <div className={styles.inputWithSpeech}>
            <FormControl>
              <Textarea
                placeholder="Add any notes about this planting..."
                value={form.values.notes ?? ''}
                onChange={(e) => form.setValues(prev => ({ ...prev, notes: e.target.value }))}
                disabled={postPlanting.isPending}
              />
            </FormControl>
            {isSpeechSupported && (
              <Button
                type="button"
                size="icon-md"
                variant={getSpeechButtonVariant()}
                onClick={startSpeechRecognition}
                disabled={postPlanting.isPending}
                className={styles.speechButton}
              >
                {getSpeechButtonIcon()}
              </Button>
            )}
          </div>
          {speechState === 'listening' && (
            <FormDescription className={styles.listeningText}>
              🎙️ Listening for notes... (speak naturally about your planting)
            </FormDescription>
          )}
          <FormMessage />
        </FormItem>

        <Button type="submit" disabled={postPlanting.isPending} className={styles.submitButton}>
          {postPlanting.isPending && <Loader2 className={styles.spinner} />}
          Plant Crop
        </Button>
      </form>
    </Form>
    </>
  );
};

const PlantNewCropFormSkeleton = () => (
  <div className={styles.form}>
    <div className={styles.grid}>
      <div className={styles.skeletonItem}>
        <Skeleton style={{ height: '1.25rem', width: '4rem', marginBottom: 'var(--spacing-2)' }} />
        <Skeleton style={{ height: '2.5rem' }} />
      </div>
      <div className={styles.skeletonItem}>
        <Skeleton style={{ height: '1.25rem', width: '3rem', marginBottom: 'var(--spacing-2)' }} />
        <Skeleton style={{ height: '2.5rem' }} />
      </div>
    </div>
    <div className={styles.skeletonItem}>
      <Skeleton style={{ height: '1.25rem', width: '6rem', marginBottom: 'var(--spacing-2)' }} />
      <Skeleton style={{ height: '2.5rem' }} />
    </div>
    <div className={styles.skeletonItem}>
      <Skeleton style={{ height: '1.25rem', width: '8rem', marginBottom: 'var(--spacing-2)' }} />
      <Skeleton style={{ height: '6rem' }} />
    </div>
    <Skeleton style={{ height: '2.5rem', width: '8rem', marginTop: 'var(--spacing-4)' }} />
  </div>
);