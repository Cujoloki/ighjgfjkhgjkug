import React from 'react';
import { useGetPlantings } from '../helpers/farmQueries';
import { Skeleton } from './Skeleton';
import { Badge } from './Badge';
import { Sprout } from 'lucide-react';
import styles from './ActivePlantingsList.module.css';

export const ActivePlantingsList = () => {
  const { data: plantings, isFetching } = useGetPlantings();

  const activePlantings = plantings?.filter(p => p.isActive)
    .sort((a, b) => new Date(b.plantedDate).getTime() - new Date(a.plantedDate).getTime());

  if (isFetching) {
    return <ActivePlantingsListSkeleton />;
  }

  if (!activePlantings || activePlantings.length === 0) {
    return (
      <div className={styles.emptyState}>
        <Sprout className={styles.emptyIcon} />
        <p>No active plantings found.</p>
        <span>Use the form above to plant a new crop.</span>
      </div>
    );
  }

  return (
    <div className={styles.listContainer}>
      <div className={styles.grid}>
        <div className={styles.headerCell}>Crop</div>
        <div className={styles.headerCell}>Row</div>
        <div className={styles.headerCell}>Planted On</div>
        <div className={styles.headerCell}>Days Active</div>
        {activePlantings.map(planting => {
          const plantedDate = new Date(planting.plantedDate);
          const daysActive = Math.floor((new Date().getTime() - plantedDate.getTime()) / (1000 * 3600 * 24));
          return (
            <React.Fragment key={planting.id}>
              <div className={styles.cell}>{planting.crop.name}</div>
              <div className={styles.cell}>
                <Badge variant="secondary">
                  Row {planting.row.rowNumber} ({planting.row.rowLength} ft)
                </Badge>
              </div>
              <div className={styles.cell}>{plantedDate.toLocaleDateString()}</div>
              <div className={styles.cell}>{daysActive} days</div>
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

const ActivePlantingsListSkeleton = () => (
  <div className={styles.listContainer}>
    <div className={styles.grid}>
      <div className={styles.headerCell}><Skeleton style={{ width: '4rem', height: '1.2rem' }} /></div>
      <div className={styles.headerCell}><Skeleton style={{ width: '3rem', height: '1.2rem' }} /></div>
      <div className={styles.headerCell}><Skeleton style={{ width: '5rem', height: '1.2rem' }} /></div>
      <div className={styles.headerCell}><Skeleton style={{ width: '6rem', height: '1.2rem' }} /></div>
      {Array.from({ length: 4 }).map((_, index) => (
        <React.Fragment key={index}>
          <div className={styles.cell}><Skeleton style={{ width: '80%', height: '1.2rem' }} /></div>
          <div className={styles.cell}><Skeleton style={{ width: '90%', height: '1.5rem' }} /></div>
          <div className={styles.cell}><Skeleton style={{ width: '70%', height: '1.2rem' }} /></div>
          <div className={styles.cell}><Skeleton style={{ width: '50%', height: '1.2rem' }} /></div>
        </React.Fragment>
      ))}
    </div>
  </div>
);