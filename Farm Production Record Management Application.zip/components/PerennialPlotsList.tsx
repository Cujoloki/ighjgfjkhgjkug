import React from 'react';
import { useGetPerennialPlots } from '../helpers/perennialQueries';
import { Skeleton } from './Skeleton';
import { MapPin, Calendar, Maximize, Clock } from 'lucide-react';
import styles from './PerennialPlotsList.module.css';

export const PerennialPlotsList = () => {
  const { data: plots, isFetching, error } = useGetPerennialPlots();

  if (isFetching) {
    return (
      <div className={styles.grid}>
        {[...Array(3)].map((_, i) => (
          <div key={i} className={styles.card}>
            <Skeleton style={{ height: '1.5rem', width: '60%', marginBottom: 'var(--spacing-2)' }} />
            <Skeleton style={{ height: '1rem', width: '40%', marginBottom: 'var(--spacing-4)' }} />
            <div className={styles.infoGrid}>
              <Skeleton style={{ height: '1rem', width: '80%' }} />
              <Skeleton style={{ height: '1rem', width: '70%' }} />
              <Skeleton style={{ height: '1rem', width: '90%' }} />
              <Skeleton style={{ height: '1rem', width: '60%' }} />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return <div className={styles.error}>Error loading plots: {error.message}</div>;
  }

  if (!plots || plots.length === 0) {
    return <div className={styles.empty}>No perennial plots found. Add one to get started!</div>;
  }

  return (
    <div className={styles.grid}>
      {plots.map(plot => (
        <div key={plot.id} className={styles.card}>
          <h3 className={styles.plotName}>{plot.plotName}</h3>
          <p className={styles.cropType}>{plot.cropType}</p>
          <div className={styles.infoGrid}>
            <div className={styles.infoItem}>
              <Calendar size={14} className={styles.icon} />
              <span>Planted: {new Date(plot.plantedDate).toLocaleDateString()}</span>
            </div>
            <div className={styles.infoItem}>
              <Maximize size={14} className={styles.icon} />
              <span>{plot.plotSizeSqft} sq ft</span>
            </div>
            {plot.locationDescription && (
              <div className={styles.infoItem}>
                <MapPin size={14} className={styles.icon} />
                <span>{plot.locationDescription}</span>
              </div>
            )}
            {plot.expectedProductiveYears && (
              <div className={styles.infoItem}>
                <Clock size={14} className={styles.icon} />
                <span>{plot.expectedProductiveYears} productive years (est.)</span>
              </div>
            )}
          </div>
          {plot.maintenanceNotes && (
            <div className={styles.notesSection}>
              <h4 className={styles.notesTitle}>Maintenance Notes</h4>
              <p className={styles.notesText}>{plot.maintenanceNotes}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};