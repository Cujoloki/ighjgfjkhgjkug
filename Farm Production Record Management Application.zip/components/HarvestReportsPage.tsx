import React from 'react';
import { Helmet } from 'react-helmet';
import { useGetWeeklyHarvestSummary } from '../helpers/weeklyReporting';
import { RevenueProgressTracker } from './RevenueProgressTracker';
import { WeeklyHarvestSummary } from './WeeklyHarvestSummary';
import styles from './HarvestReportsPage.module.css';

export const HarvestReportsPage = () => {
  const { data: weeklySummary, isFetching } = useGetWeeklyHarvestSummary();

  const totalRevenue = weeklySummary && weeklySummary.length > 0
    ? weeklySummary[weeklySummary.length - 1].cumulativeValue
    : 0;

  return (
    <>
      <Helmet>
        <title>Harvest Reports - Hourglass Tree Farms</title>
        <meta name="description" content="View weekly harvest reports and revenue tracking." />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.header}>
          <h1 className={styles.title}>Harvest Reports</h1>
          <p className={styles.subtitle}>
            Weekly summaries, revenue tracking, and performance analysis.
          </p>
        </header>

        <div className={styles.dashboardGrid}>
          <div className={styles.mainMetric}>
            <RevenueProgressTracker
              currentValue={totalRevenue}
              isLoading={isFetching}
            />
          </div>
          <div className={styles.secondaryMetric}>
            <WeeklyHarvestSummary data={weeklySummary ?? []} isLoading={isFetching} />
          </div>
        </div>
      </div>
    </>
  );
};