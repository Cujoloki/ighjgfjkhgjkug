import React, { useState, useEffect } from 'react';
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage } from './Form';
import { Input } from './Input';
import { Button } from './Button';
import { Checkbox } from './Checkbox';
import { schema as postRowsSchema } from '../endpoints/rows_POST.schema';
import { usePostRows } from '../helpers/rowQueries';
import { toast } from 'sonner';

type RowCreateFormProps = {
  onClose: () => void;
};

export function RowCreateForm({ onClose }: RowCreateFormProps) {
  const [isBatch, setIsBatch] = useState(false);
  const postRowsMutation = usePostRows();

  const form = useForm({
    schema: postRowsSchema,
    defaultValues: {
      type: 'single' as const,
      rowNumber: 1,
      rowLength: 50,
    },
  });

  useEffect(() => {
    if (isBatch) {
      form.setValues({
        type: 'batch' as const,
        count: 1,
        rowLength: 50,
      });
    } else {
      form.setValues({
        type: 'single' as const,
        rowNumber: 1,
        rowLength: 50,
      });
    }
  }, [isBatch, form.setValues]);

  const onSubmit = (values: z.infer<typeof postRowsSchema>) => {
    postRowsMutation.mutate(values, {
      onSuccess: () => {
        toast.success('Row(s) created successfully.');
        onClose();
      },
      onError: (error) => {
        toast.error(`Failed to create row(s): ${error.message}`);
      },
    });
  };

  const isSubmitting = postRowsMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-2)', marginBottom: 'var(--spacing-4)' }}>
          <Checkbox id="batch-mode" checked={isBatch} onChange={(e) => setIsBatch(e.target.checked)} />
          <label htmlFor="batch-mode" style={{ fontSize: '0.875rem', color: 'var(--foreground)', cursor: 'pointer' }}>
            Create multiple rows (batch mode)
          </label>
        </div>

        {form.values.type === 'batch' && (
          <FormItem name="count">
            <FormLabel>Number of Rows</FormLabel>
            <FormControl>
              <Input
                type="number"
                placeholder="e.g., 10"
                value={form.values.count || ''}
                onChange={(e) => 
                  form.setValues((prev) => ({
                    ...prev,
                    count: e.target.value ? parseInt(e.target.value, 10) : 1,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}

        {form.values.type === 'single' && (
          <FormItem name="rowNumber">
            <FormLabel>Row Number</FormLabel>
            <FormControl>
              <Input
                type="number"
                placeholder="e.g., 1"
                value={form.values.rowNumber || ''}
                onChange={(e) => 
                  form.setValues((prev) => ({
                    ...prev,
                    rowNumber: e.target.value ? parseInt(e.target.value, 10) : 1,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}

        <FormItem name="rowLength">
          <FormLabel>Row Length (feet)</FormLabel>
          <FormControl>
            <Input
              type="number"
              placeholder="e.g., 50"
              value={form.values.rowLength || ''}
              onChange={(e) => 
                form.setValues((prev) => ({
                  ...prev,
                  rowLength: e.target.value ? parseFloat(e.target.value) : 50,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--spacing-2)', marginTop: 'var(--spacing-6)' }}>
          <Button type="button" variant="ghost" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Creating...' : 'Create Row(s)'}
          </Button>
        </div>
      </form>
    </Form>
  );
}