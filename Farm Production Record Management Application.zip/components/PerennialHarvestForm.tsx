import React, { useState, useMemo, useRef, useEffect } from 'react';
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from './Form';
import { useGetPerennialPlots, usePostPerennialHarvest } from '../helpers/perennialQueries';
import { Input } from './Input';
import { Textarea } from './Textarea';
import { Button } from './Button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './Select';
import { Popover, PopoverTrigger, PopoverContent } from './Popover';
import { Calendar } from './Calendar';
import { Calendar as CalendarIcon, DollarSign, Loader2, Mic, MicOff, Square } from 'lucide-react';
import { schema as postPerennialHarvestSchema } from '../endpoints/perennial-harvests_POST.schema';
import { toast } from 'sonner';
import styles from './PerennialHarvestForm.module.css';

// Web Speech API type declarations
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: ((event: Event) => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: ((event: Event) => void) | null;
}

interface SpeechRecognitionStatic {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}

const formSchema = postPerennialHarvestSchema.extend({
  perennialPlotId: z.string().min(1, "Please select a plot."),
});

type FormValues = z.infer<typeof formSchema>;
type SpeechRecognitionState = 'idle' | 'listening' | 'processing';

export const PerennialHarvestForm = () => {
  const { data: plots, isFetching: isFetchingPlots } = useGetPerennialPlots();
  const postHarvestMutation = usePostPerennialHarvest();
  const [speechState, setSpeechState] = useState<SpeechRecognitionState>('idle');
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const form = useForm({
    schema: formSchema,
    defaultValues: {
      perennialPlotId: '',
      poundsHarvested: 0,
      pricePerPound: 0,
      harvestDate: new Date(),
      harvestNotes: '',
    },
  });

  const calculatedValue = useMemo(() => {
    return form.values.poundsHarvested * form.values.pricePerPound;
  }, [form.values.poundsHarvested, form.values.pricePerPound]);

  useEffect(() => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        setSpeechState('listening');
        toast.info('Listening...', { duration: 2000 });
      };

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        const currentNotes = form.values.harvestNotes || '';
        form.setValues(prev => ({ ...prev, harvestNotes: currentNotes ? `${currentNotes} ${transcript}` : transcript }));
        setSpeechState('idle');
        toast.success('Speech recognized!');
      };

      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setSpeechState('idle');
        toast.error(`Speech recognition error: ${event.error}`);
      };

      recognitionRef.current.onend = () => {
        if (speechState === 'listening') {
          setSpeechState('idle');
        }
      };
    }
  }, [speechState, form]);

  const startSpeechRecognition = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition is not supported.');
      return;
    }
    if (speechState === 'listening') {
      recognitionRef.current.stop();
      return;
    }
    try {
      recognitionRef.current.start();
    } catch (e) {
      console.error(e);
      setSpeechState('idle');
      toast.error('Could not start speech recognition.');
    }
  };

  const getSpeechButtonIcon = () => {
    if (speechState === 'listening') {
      return <Square size={16} className={styles.recordingIcon} />;
    }
    return speechState === 'idle' ? <Mic size={16} /> : <MicOff size={16} />;
  };

  const isSpeechSupported = typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);

  const onSubmit = (values: FormValues) => {
    const submissionData = {
      ...values,
      perennialPlotId: parseInt(values.perennialPlotId, 10),
      poundsHarvested: Number(values.poundsHarvested),
      pricePerPound: Number(values.pricePerPound),
    };

    postHarvestMutation.mutate(submissionData, {
      onSuccess: () => {
        toast.success('Perennial harvest recorded successfully!');
        form.setValues({
          perennialPlotId: '',
          poundsHarvested: 0,
          pricePerPound: 0,
          harvestDate: new Date(),
          harvestNotes: '',
        });
      },
      onError: (error) => {
        toast.error(`Failed to record harvest: ${error.message}`);
      },
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={styles.form}>
        <FormItem name="perennialPlotId">
          <FormLabel>Plot</FormLabel>
          <Select onValueChange={(value) => form.setValues(prev => ({ ...prev, perennialPlotId: value }))} value={form.values.perennialPlotId} disabled={isFetchingPlots || postHarvestMutation.isPending}>
            <FormControl>
              <SelectTrigger>
                <SelectValue placeholder="Select a plot..." />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {plots?.map(p => (
                <SelectItem key={p.id} value={String(p.id)}>
                  {p.plotName} ({p.cropType})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>

        <div className={styles.grid}>
          <FormItem name="poundsHarvested">
            <FormLabel>Pounds Harvested</FormLabel>
            <FormControl>
              <Input type="number" placeholder="e.g., 25.5" value={form.values.poundsHarvested} onChange={(e) => form.setValues(prev => ({ ...prev, poundsHarvested: e.target.valueAsNumber || 0 }))} disabled={postHarvestMutation.isPending} />
            </FormControl>
            <FormMessage />
          </FormItem>
          <FormItem name="pricePerPound">
            <FormLabel>Price per Pound ($)</FormLabel>
            <FormControl>
              <Input type="number" placeholder="e.g., 6.50" value={form.values.pricePerPound} onChange={(e) => form.setValues(prev => ({ ...prev, pricePerPound: e.target.valueAsNumber || 0 }))} disabled={postHarvestMutation.isPending} />
            </FormControl>
            <FormMessage />
          </FormItem>
        </div>

        <FormItem name="harvestDate">
          <FormLabel>Harvest Date</FormLabel>
          <Popover>
            <PopoverTrigger asChild>
              <FormControl>
                <Button variant="outline" className={styles.dateButton} disabled={postHarvestMutation.isPending}>
                  {form.values.harvestDate ? new Date(form.values.harvestDate).toLocaleDateString() : <span>Pick a date</span>}
                  <CalendarIcon size={16} />
                </Button>
              </FormControl>
            </PopoverTrigger>
            <PopoverContent removeBackgroundAndPadding>
              <Calendar mode="single" selected={form.values.harvestDate} onSelect={(date) => date && form.setValues(prev => ({ ...prev, harvestDate: date }))} initialFocus />
            </PopoverContent>
          </Popover>
          <FormMessage />
        </FormItem>

        <FormItem name="harvestNotes">
          <FormLabel>Notes (Optional)</FormLabel>
          <div className={styles.inputWithSpeech}>
            <FormControl>
              <Textarea placeholder="Any notes about this harvest..." value={form.values.harvestNotes ?? ''} onChange={(e) => form.setValues(prev => ({ ...prev, harvestNotes: e.target.value }))} disabled={postHarvestMutation.isPending} />
            </FormControl>
            {isSpeechSupported && (
              <Button type="button" size="icon-md" variant={speechState === 'listening' ? 'destructive' : 'outline'} onClick={startSpeechRecognition} disabled={postHarvestMutation.isPending}>
                {getSpeechButtonIcon()}
              </Button>
            )}
          </div>
          <FormMessage />
        </FormItem>

        {calculatedValue > 0 && (
          <div className={styles.valueDisplay}>
            <DollarSign size={20} className={styles.valueIcon} />
            <div>
              <p className={styles.valueLabel}>Estimated Value</p>
              <p className={styles.valueAmount}>${calculatedValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            </div>
          </div>
        )}

        <Button type="submit" disabled={postHarvestMutation.isPending} className={styles.submitButton}>
          {postHarvestMutation.isPending && <Loader2 size={16} className={styles.spinner} />}
          {postHarvestMutation.isPending ? 'Saving...' : 'Record Harvest'}
        </Button>
      </form>
    </Form>
  );
};