import React from 'react';
import { Helmet } from 'react-helmet';
import { toast } from 'sonner';
import { useGetFarmSettings, usePostFarmSettings } from '../helpers/farmSettingsQueries';
import { FarmSettingsForm, FarmSettingsFormSkeleton } from './FarmSettingsForm';
import { RowManagementPage } from './RowManagementPage';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './Tabs';
import { SettingType } from '../helpers/farmSettingTypes';
import styles from './FarmSettingsPage.module.css';

export const FarmSettingsPage = () => {
  const { data: settings, isFetching, error } = useGetFarmSettings();
  const updateSettingsMutation = usePostFarmSettings();

  const handleSubmit = (values: Record<string, string>) => {
    if (!settings) return;

    const payload = settings.map(setting => ({
      settingKey: setting.settingKey,
      settingValue: values[setting.settingKey],
      settingType: setting.settingType as SettingType,
    }));

    updateSettingsMutation.mutate(payload, {
      onSuccess: () => {
        toast.success('Farm settings updated successfully!');
      },
      onError: (err) => {
        const errorMessage = err instanceof Error ? err.message : 'Failed to update settings.';
        toast.error(errorMessage);
        console.error('Failed to update settings:', err);
      },
    });
  };

  return (
    <>
      <Helmet>
        <title>Farm Configuration - Hourglass Tree Farms</title>
        <meta name="description" content="Manage your farm's settings and row layout configuration." />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.header}>
          <h1 className={styles.title}>Farm Configuration</h1>
          <p className={styles.subtitle}>
            Configure your farm settings and manage row layout.
          </p>
        </header>
        <main className={styles.content}>
          <Tabs defaultValue="settings" className={styles.tabs}>
            <TabsList className={styles.tabsList}>
              <TabsTrigger value="settings">General Settings</TabsTrigger>
              <TabsTrigger value="rows">Row Management</TabsTrigger>
            </TabsList>
            <TabsContent value="settings" className={styles.tabContent}>
              {isFetching && <FarmSettingsFormSkeleton />}
              {error && <div className={styles.errorState}>Error loading settings: {error.message}</div>}
              {settings && (
                <FarmSettingsForm
                  settings={settings}
                  onSubmit={handleSubmit}
                  isSubmitting={updateSettingsMutation.isPending}
                />
              )}
            </TabsContent>
            <TabsContent value="rows" className={styles.tabContent}>
              <RowManagementPage />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </>
  );
};