import React, { useState, useRef, useEffect } from 'react';
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from './Form';
import { Input } from './Input';
import { Textarea } from './Textarea';
import { Button } from './Button';
import { Popover, PopoverTrigger, PopoverContent } from './Popover';
import { Calendar } from './Calendar';
import { Calendar as CalendarIcon, Loader2, Mic, MicOff, Square } from 'lucide-react';
import { usePostPerennialPlot } from '../helpers/perennialQueries';
import { schema as postPerennialPlotSchema } from '../endpoints/perennial-plots_POST.schema';
import { toast } from 'sonner';
import styles from './PerennialPlotForm.module.css';

// Web Speech API type declarations
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: ((event: Event) => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: ((event: Event) => void) | null;
}

interface SpeechRecognitionStatic {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}

type FormValues = z.infer<typeof postPerennialPlotSchema>;
type SpeechRecognitionState = 'idle' | 'listening' | 'processing';

export const PerennialPlotForm = () => {
  const postPlotMutation = usePostPerennialPlot();
  const [speechState, setSpeechState] = useState<SpeechRecognitionState>('idle');
  const [currentSpeechField, setCurrentSpeechField] = useState<'location' | 'maintenance' | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const form = useForm({
    schema: postPerennialPlotSchema,
    defaultValues: {
      plotName: '',
      cropType: '',
      plantedDate: new Date(),
      plotSizeSqft: 0,
      expectedProductiveYears: undefined,
      locationDescription: '',
      maintenanceNotes: '',
    },
  });

  useEffect(() => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        setSpeechState('listening');
        toast.info('Listening...', { duration: 2000 });
      };

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        if (currentSpeechField === 'location') {
          const currentNotes = form.values.locationDescription || '';
          form.setValues(prev => ({ ...prev, locationDescription: currentNotes ? `${currentNotes} ${transcript}` : transcript }));
        } else if (currentSpeechField === 'maintenance') {
          const currentNotes = form.values.maintenanceNotes || '';
          form.setValues(prev => ({ ...prev, maintenanceNotes: currentNotes ? `${currentNotes} ${transcript}` : transcript }));
        }
        setSpeechState('idle');
        setCurrentSpeechField(null);
        toast.success('Speech recognized!');
      };

      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setSpeechState('idle');
        setCurrentSpeechField(null);
        toast.error(`Speech recognition error: ${event.error}`);
      };

      recognitionRef.current.onend = () => {
        if (speechState === 'listening') {
          setSpeechState('idle');
          setCurrentSpeechField(null);
        }
      };
    }
  }, [currentSpeechField, speechState, form]);

  const startSpeechRecognition = (field: 'location' | 'maintenance') => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition is not supported.');
      return;
    }
    if (speechState === 'listening') {
      recognitionRef.current.stop();
      return;
    }
    setCurrentSpeechField(field);
    try {
      recognitionRef.current.start();
    } catch (e) {
      console.error(e);
      setSpeechState('idle');
      setCurrentSpeechField(null);
      toast.error('Could not start speech recognition.');
    }
  };

  const getSpeechButtonIcon = (field: 'location' | 'maintenance') => {
    if (speechState === 'listening' && currentSpeechField === field) {
      return <Square size={16} className={styles.recordingIcon} />;
    }
    return speechState === 'idle' ? <Mic size={16} /> : <MicOff size={16} />;
  };

  const isSpeechSupported = typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);

  const onSubmit = (values: FormValues) => {
    postPlotMutation.mutate(values, {
      onSuccess: () => {
        toast.success('Perennial plot created successfully!');
        form.setValues({
          plotName: '',
          cropType: '',
          plantedDate: new Date(),
          plotSizeSqft: 0,
          expectedProductiveYears: undefined,
          locationDescription: '',
          maintenanceNotes: '',
        });
      },
      onError: (error) => {
        toast.error(`Failed to create plot: ${error.message}`);
      },
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={styles.form}>
        <div className={styles.grid}>
          <FormItem name="plotName">
            <FormLabel>Plot Name</FormLabel>
            <FormControl>
              <Input
                placeholder="e.g., North Blueberry Patch"
                value={form.values.plotName}
                onChange={(e) => form.setValues(prev => ({ ...prev, plotName: e.target.value }))}
                disabled={postPlotMutation.isPending}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
          <FormItem name="cropType">
            <FormLabel>Crop Type</FormLabel>
            <FormControl>
              <Input
                placeholder="e.g., Blueberries"
                value={form.values.cropType}
                onChange={(e) => form.setValues(prev => ({ ...prev, cropType: e.target.value }))}
                disabled={postPlotMutation.isPending}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        </div>

        <FormItem name="plantedDate">
          <FormLabel>Planted Date</FormLabel>
          <Popover>
            <PopoverTrigger asChild>
              <FormControl>
                <Button variant="outline" className={styles.dateButton} disabled={postPlotMutation.isPending}>
                  {form.values.plantedDate ? new Date(form.values.plantedDate).toLocaleDateString() : <span>Pick a date</span>}
                  <CalendarIcon size={16} />
                </Button>
              </FormControl>
            </PopoverTrigger>
            <PopoverContent removeBackgroundAndPadding>
              <Calendar
                mode="single"
                selected={form.values.plantedDate}
                onSelect={(date) => date && form.setValues(prev => ({ ...prev, plantedDate: date }))}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          <FormMessage />
        </FormItem>

        <div className={styles.grid}>
          <FormItem name="plotSizeSqft">
            <FormLabel>Plot Size (sq ft)</FormLabel>
            <FormControl>
              <Input
                type="number"
                placeholder="e.g., 500"
                value={form.values.plotSizeSqft}
                onChange={(e) => form.setValues(prev => ({ ...prev, plotSizeSqft: e.target.valueAsNumber || 0 }))}
                disabled={postPlotMutation.isPending}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
          <FormItem name="expectedProductiveYears">
            <FormLabel>Productive Years (Est.)</FormLabel>
            <FormControl>
              <Input
                type="number"
                placeholder="e.g., 10"
                value={form.values.expectedProductiveYears ?? ''}
                onChange={(e) => form.setValues(prev => ({ ...prev, expectedProductiveYears: e.target.valueAsNumber || undefined }))}
                disabled={postPlotMutation.isPending}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        </div>

        <FormItem name="locationDescription">
          <FormLabel>Location Description</FormLabel>
          <div className={styles.inputWithSpeech}>
            <FormControl>
              <Textarea
                placeholder="e.g., Behind the main barn, west side"
                value={form.values.locationDescription ?? ''}
                onChange={(e) => form.setValues(prev => ({ ...prev, locationDescription: e.target.value }))}
                disabled={postPlotMutation.isPending}
              />
            </FormControl>
            {isSpeechSupported && (
              <Button type="button" size="icon-md" variant={speechState === 'listening' && currentSpeechField === 'location' ? 'destructive' : 'outline'} onClick={() => startSpeechRecognition('location')} disabled={postPlotMutation.isPending || (speechState === 'listening' && currentSpeechField !== 'location')}>
                {getSpeechButtonIcon('location')}
              </Button>
            )}
          </div>
          <FormMessage />
        </FormItem>

        <FormItem name="maintenanceNotes">
          <FormLabel>Maintenance Notes</FormLabel>
          <div className={styles.inputWithSpeech}>
            <FormControl>
              <Textarea
                placeholder="e.g., Fertilize in early spring"
                value={form.values.maintenanceNotes ?? ''}
                onChange={(e) => form.setValues(prev => ({ ...prev, maintenanceNotes: e.target.value }))}
                disabled={postPlotMutation.isPending}
              />
            </FormControl>
            {isSpeechSupported && (
              <Button type="button" size="icon-md" variant={speechState === 'listening' && currentSpeechField === 'maintenance' ? 'destructive' : 'outline'} onClick={() => startSpeechRecognition('maintenance')} disabled={postPlotMutation.isPending || (speechState === 'listening' && currentSpeechField !== 'maintenance')}>
                {getSpeechButtonIcon('maintenance')}
              </Button>
            )}
          </div>
          <FormMessage />
        </FormItem>

        <Button type="submit" disabled={postPlotMutation.isPending} className={styles.submitButton}>
          {postPlotMutation.isPending && <Loader2 size={16} className={styles.spinner} />}
          {postPlotMutation.isPending ? 'Saving...' : 'Create Plot'}
        </Button>
      </form>
    </Form>
  );
};