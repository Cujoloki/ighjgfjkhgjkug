import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import styles from './SharedLayout.module.css';
import { Leaf, Settings } from 'lucide-react';

const navLinks = [
  { href: '/', label: 'Dashboard' },
  { href: '/plant', label: 'Plant Crops' },
  { href: '/perennials', label: 'Perennials' },
  { href: '/harvest', label: 'Record Harvest' },
  { href: '/records', label: 'Records' },
  { href: '/settings', label: 'Settings' },
];

export const SharedLayout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();

  return (
    <div className={styles.layout}>
      <header className={styles.header}>
        <div className={styles.logoContainer}>
          <Leaf className={styles.logoIcon} />
          <span className={styles.logoText}>Hourglass Tree Farms</span>
        </div>
        <nav className={styles.nav}>
          {navLinks.map(link => (
            <Link
              key={link.href}
              to={link.href}
              className={`${styles.navLink} ${location.pathname === link.href ? styles.active : ''}`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

      </header>
      <main className={styles.main}>
        {children}
      </main>
    </div>
  );
};