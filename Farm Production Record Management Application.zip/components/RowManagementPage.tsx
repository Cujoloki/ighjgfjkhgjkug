import React, { useState } from 'react';
import { useGetRows } from '../helpers/farmQueries';
import { useDeleteRow } from '../helpers/rowQueries';
import { RowWithPlanting } from '../endpoints/rows_GET.schema';
import { RowManagementForm } from './RowManagementForm';
import { Button } from './Button';
import { Skeleton } from './Skeleton';
import { Plus, Edit, Trash2, AlertTriangle } from 'lucide-react';
import styles from './RowManagementPage.module.css';
import { toast } from 'sonner';

export function RowManagementPage() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRow, setEditingRow] = useState<RowWithPlanting | null>(null);

  const { data: rows, isLoading, error } = useGetRows();
  const deleteRowMutation = useDeleteRow();

  const handleAddClick = () => {
    setEditingRow(null);
    setIsFormOpen(true);
  };

  const handleEditClick = (row: RowWithPlanting) => {
    setEditingRow(row);
    setIsFormOpen(true);
  };

  const handleDeleteClick = (row: RowWithPlanting) => {
    if (window.confirm(`Are you sure you want to delete Row ${row.rowNumber}? This cannot be undone.`)) {
      deleteRowMutation.mutate({ id: row.id }, {
        onSuccess: () => {
          toast.success(`Row ${row.rowNumber} deleted successfully.`);
        },
        onError: (err) => {
          toast.error(`Failed to delete row: ${err.message}`);
        },
      });
    }
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingRow(null);
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className={styles.skeletonGrid}>
          {[...Array(10)].map((_, i) => (
            <Skeleton key={i} className={styles.skeletonCard} />
          ))}
        </div>
      );
    }

    if (error) {
      return (
        <div className={styles.errorState}>
          <AlertTriangle size={48} />
          <h3>Error loading farm rows</h3>
          <p>{error.message}</p>
        </div>
      );
    }

    if (!rows || rows.length === 0) {
      return (
        <div className={styles.emptyState}>
          <h3>No farm rows configured.</h3>
          <p>Get started by adding your first row or a batch of rows.</p>
          <Button onClick={handleAddClick}>
            <Plus size={16} /> Add Rows
          </Button>
        </div>
      );
    }

    return (
      <div className={styles.grid}>
        {rows.map((row) => (
          <div key={row.id} className={styles.rowCard}>
            <div className={styles.rowInfo}>
              <span className={styles.rowNumber}>Row {row.rowNumber}</span>
              <span className={styles.rowLength}>{row.rowLength} ft</span>
            </div>
            <div className={styles.plantingStatus}>
              {row.currentPlanting ? (
                <span className={styles.active}>{row.currentPlanting.crop.name}</span>
              ) : (
                <span className={styles.inactive}>Empty</span>
              )}
            </div>
            <div className={styles.rowActions}>
              <Button variant="ghost" size="icon-sm" onClick={() => handleEditClick(row)}>
                <Edit size={14} />
              </Button>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => handleDeleteClick(row)}
                disabled={!!row.currentPlanting || deleteRowMutation.isPending}
                className={styles.deleteButton}
              >
                <Trash2 size={14} />
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (isFormOpen) {
    return <RowManagementForm row={editingRow} onClose={handleCloseForm} />;
  }

  return (
    <div className={styles.pageContainer}>
      <header className={styles.header}>
        <h1>Farm Row Management</h1>
        <Button onClick={handleAddClick}>
          <Plus size={16} /> Add Rows
        </Button>
      </header>
      <main className={styles.mainContent}>
        {renderContent()}
      </main>
    </div>
  );
}