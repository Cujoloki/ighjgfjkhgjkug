import React from 'react';
import { Skeleton } from './Skeleton';
import { useGetFarmSettings } from '../helpers/farmSettingsQueries';
import styles from './RevenueProgressTracker.module.css';

interface RevenueProgressTrackerProps {
  currentValue: number;
  isLoading: boolean;
  className?: string;
}

const RevenueProgressTrackerSkeleton = () => (
  <div className={styles.container}>
    <div className={styles.header}>
      <Skeleton style={{ height: '1.75rem', width: '220px' }} />
      <Skeleton style={{ height: '1rem', width: '180px' }} />
    </div>
    <div className={styles.progressBarContainer}>
      <Skeleton style={{ height: '1rem', width: '100%' }} />
    </div>
    <div className={styles.stats}>
      <div className={styles.statItem}>
        <Skeleton style={{ height: '1rem', width: '100px' }} />
        <Skeleton style={{ height: '1.5rem', width: '80px' }} />
      </div>
      <div className={styles.statItem}>
        <Skeleton style={{ height: '1rem', width: '120px' }} />
        <Skeleton style={{ height: '1.5rem', width: '100px' }} />
      </div>
      <div className={styles.statItem}>
        <Skeleton style={{ height: '1rem', width: '80px' }} />
        <Skeleton style={{ height: '1.5rem', width: '60px' }} />
      </div>
    </div>
  </div>
);

export const RevenueProgressTracker = ({
  currentValue,
  isLoading,
  className,
}: RevenueProgressTrackerProps) => {
  const { data: farmSettings, isFetching: settingsLoading, error: settingsError } = useGetFarmSettings();

  // Extract revenue target from settings, fallback to 61453
  const getRevenueTarget = (): number => {
    if (!farmSettings) {
      return 61453; // Default fallback
    }

    const revenueTargetSetting = farmSettings.find(
      (setting) => setting.settingKey === 'revenue_target'
    );

    if (!revenueTargetSetting) {
      console.log('Revenue target setting not found, using default value of 61453');
      return 61453;
    }

    const targetValue = typeof revenueTargetSetting.settingValue === 'number' 
      ? revenueTargetSetting.settingValue 
      : parseFloat(revenueTargetSetting.settingValue.toString());

    if (isNaN(targetValue) || targetValue <= 0) {
      console.log('Invalid revenue target value, using default value of 61453');
      return 61453;
    }

    return targetValue;
  };

  const targetValue = getRevenueTarget();
  const shouldShowLoading = isLoading || settingsLoading;

  if (shouldShowLoading) {
    return <RevenueProgressTrackerSkeleton />;
  }

  // Log settings error but don't prevent rendering with fallback
  if (settingsError) {
    console.error('Error loading farm settings:', settingsError.message);
  }

  const percentage = targetValue > 0 ? (currentValue / targetValue) * 100 : 0;
  const clampedPercentage = Math.min(percentage, 100);
  const remaining = Math.max(0, targetValue - currentValue);

  return (
    <div className={`${styles.container} ${className ?? ''}`}>
      <div className={styles.header}>
        <h3 className={styles.title}>Annual Revenue Goal</h3>
        <p className={styles.subtitle}>
          Tracking progress towards the ${targetValue.toLocaleString()} target.
        </p>
      </div>
      <div className={styles.progressBarContainer}>
        <div className={styles.progressBar} style={{ width: `${clampedPercentage}%` }} />
      </div>
      <div className={styles.stats}>
        <div className={styles.statItem}>
          <span className={styles.statLabel}>Current Revenue</span>
          <span className={styles.statValue}>
            ${currentValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        <div className={styles.statItem}>
          <span className={styles.statLabel}>Remaining</span>
          <span className={styles.statValue}>
            ${remaining.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        <div className={styles.statItem}>
          <span className={styles.statLabel}>Progress</span>
          <span className={styles.statValue}>
            {clampedPercentage.toFixed(1)}%
          </span>
        </div>
      </div>
    </div>
  );
};