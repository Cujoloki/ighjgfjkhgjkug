import React from 'react';
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage } from './Form';
import { Input } from './Input';
import { Button } from './Button';
import { RowWithPlanting } from '../endpoints/rows_GET.schema';
import { schema as updateRowSchema } from '../endpoints/rows/update_POST.schema';
import { useUpdateRow } from '../helpers/rowQueries';
import { toast } from 'sonner';

type RowEditFormProps = {
  row: RowWithPlanting;
  onClose: () => void;
};

export function RowEditForm({ row, onClose }: RowEditFormProps) {
  const updateRowMutation = useUpdateRow();

  const form = useForm({
    schema: updateRowSchema,
    defaultValues: {
      id: row.id,
      rowLength: row.rowLength,
    },
  });

  const onSubmit = (values: z.infer<typeof updateRowSchema>) => {
    updateRowMutation.mutate(values, {
      onSuccess: () => {
        toast.success(`Row ${row.rowNumber} updated successfully.`);
        onClose();
      },
      onError: (error) => {
        toast.error(`Failed to update row: ${error.message}`);
      },
    });
  };

  const isSubmitting = updateRowMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <FormItem name="rowLength">
          <FormLabel>Row Length (feet)</FormLabel>
          <FormControl>
            <Input
              type="number"
              placeholder="e.g., 50"
              value={form.values.rowLength || ''}
              onChange={(e) => 
                form.setValues((prev) => ({
                  ...prev,
                  rowLength: e.target.value ? parseFloat(e.target.value) : prev.rowLength,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--spacing-2)', marginTop: 'var(--spacing-6)' }}>
          <Button type="button" variant="ghost" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </Form>
  );
}