import React, { useState, useEffect } from 'react';
import { useGetRows } from '../helpers/farmQueries';
import { useAssignRowsToPlot } from '../helpers/plotQueries';
import { PlotWithRows } from '../endpoints/plots_GET.schema';
import { Button } from './Button';
import { Checkbox } from './Checkbox';
import { Skeleton } from './Skeleton';
import { AlertTriangle } from 'lucide-react';
import styles from './PlotRowAssignment.module.css';

interface PlotRowAssignmentProps {
  plot: PlotWithRows;
  onClose: () => void;
  className?: string;
}

export function PlotRowAssignment({ plot, onClose, className }: PlotRowAssignmentProps) {
  const { data: allRows, isLoading, isError, error } = useGetRows();
  const assignRowsMutation = useAssignRowsToPlot();

  const [selectedRowIds, setSelectedRowIds] = useState<Set<number>>(new Set());

  useEffect(() => {
    if (plot.rows) {
      setSelectedRowIds(new Set(plot.rows.map(r => r.id)));
    }
  }, [plot.rows]);

  const handleToggleRow = (rowId: number) => {
    setSelectedRowIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(rowId)) {
        newSet.delete(rowId);
      } else {
        newSet.add(rowId);
      }
      return newSet;
    });
  };

  const handleSave = () => {
    assignRowsMutation.mutate(
      { plotId: plot.id, rowIds: Array.from(selectedRowIds) },
      { onSuccess: onClose }
    );
  };

  const renderRowList = () => {
    if (isLoading) {
      return Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className={styles.rowItem}>
          <Skeleton style={{ width: '1.25rem', height: '1.25rem' }} />
          <Skeleton style={{ height: '1rem', width: '100px' }} />
        </div>
      ));
    }

    if (isError) {
      return (
        <div className={styles.errorState}>
          <AlertTriangle />
          <p>Error loading rows: {error.message}</p>
        </div>
      );
    }

    if (!allRows || allRows.length === 0) {
      return <p>No farm rows found.</p>;
    }

    return allRows.map(row => {
      const isAssignedToOtherPlot = row.currentPlanting && row.currentPlanting.plantingId !== null; // Simplified logic
      const isDisabled = false; // Future: check if row is part of another plot

      return (
        <label
          key={row.id}
          className={`${styles.rowItem} ${isDisabled ? styles.disabled : ''}`}
          htmlFor={`row-${row.id}`}
        >
          <Checkbox
            id={`row-${row.id}`}
            checked={selectedRowIds.has(row.id)}
            onChange={() => handleToggleRow(row.id)}
            disabled={isDisabled}
          />
          <span>Row {row.rowNumber} ({row.rowLength} ft)</span>
          {isAssignedToOtherPlot && <span className={styles.assignedBadge}>Occupied</span>}
        </label>
      );
    });
  };

  return (
    <div className={`${styles.container} ${className || ''}`}>
      <div className={styles.rowList}>
        {renderRowList()}
      </div>
      <div className={styles.actions}>
        <Button variant="ghost" onClick={onClose} disabled={assignRowsMutation.isPending}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={assignRowsMutation.isPending}>
          {assignRowsMutation.isPending ? 'Saving...' : 'Save Assignments'}
        </Button>
      </div>
    </div>
  );
}