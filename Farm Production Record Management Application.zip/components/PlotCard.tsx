import React from 'react';
import { PlotWithRows } from '../endpoints/plots_GET.schema';
import { Button } from './Button';
import { MoreHorizontal, Edit, Trash2, List } from 'lucide-react';
import { Popover, PopoverTrigger, PopoverContent } from './Popover';
import styles from './PlotCard.module.css';

interface PlotCardProps {
  plot: PlotWithRows;
  onEdit: () => void;
  onDelete: () => void;
  onAssignRows: () => void;
  className?: string;
}

export function PlotCard({ plot, onEdit, onDelete, onAssignRows, className }: PlotCardProps) {
  const totalLength = plot.rows.reduce((sum, row) => sum + row.rowLength, 0);

  return (
    <div className={`${styles.card} ${className || ''}`}>
      <div className={styles.colorBar} style={{ backgroundColor: plot.color || 'var(--muted)' }} />
      <div className={styles.cardContent}>
        <div className={styles.header}>
          <h3 className={styles.title}>{plot.name}</h3>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon-sm" aria-label="Plot options">
                <MoreHorizontal size={16} />
              </Button>
            </PopoverTrigger>
            <PopoverContent className={styles.popoverContent}>
              <button className={styles.menuItem} onClick={onEdit}>
                <Edit size={14} /> Edit Plot
              </button>
              <button className={styles.menuItem} onClick={onAssignRows}>
                <List size={14} /> Assign Rows
              </button>
              <button className={`${styles.menuItem} ${styles.deleteItem}`} onClick={onDelete}>
                <Trash2 size={14} /> Delete Plot
              </button>
            </PopoverContent>
          </Popover>
        </div>
        <p className={styles.description}>{plot.description || 'No description provided.'}</p>
        <div className={styles.stats}>
          <div className={styles.statItem}>
            <span className={styles.statValue}>{plot.rows.length}</span>
            <span className={styles.statLabel}>Rows</span>
          </div>
          <div className={styles.statItem}>
            <span className={styles.statValue}>{totalLength}</span>
            <span className={styles.statLabel}>Total Feet</span>
          </div>
        </div>
      </div>
    </div>
  );
}