import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './plant.module.css';
import { PlantNewCropForm } from '../components/PlantNewCropForm';
import { ActivePlantingsList } from '../components/ActivePlantingsList';
import { Separator } from '../components/Separator';

export default function PlantPage() {
  return (
    <>
      <Helmet>
        <title>Planting Management - Hourglass Tree Farms</title>
        <meta
          name="description"
          content="Manage crop plantings, track rotations, and view active plantings."
        />
      </Helmet>
      <div className={styles.container}>
        <header className={styles.header}>
          <h1 className={styles.title}>Planting Management</h1>
          <p className={styles.subtitle}>
            Add new plantings and monitor your active crops and row rotations.
          </p>
        </header>

        <div className={styles.content}>
          <div className={styles.formSection}>
            <h2 className={styles.sectionTitle}>New Planting</h2>
            <PlantNewCropForm />
          </div>

          <Separator />

          <div className={styles.listSection}>
            <h2 className={styles.sectionTitle}>Active Plantings</h2>
            <ActivePlantingsList />
          </div>
        </div>
      </div>
    </>
  );
}