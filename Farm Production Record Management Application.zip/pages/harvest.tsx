import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';

// Web Speech API type declarations
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: ((event: Event) => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: ((event: Event) => void) | null;
}

interface SpeechRecognitionStatic {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}
import { z } from 'zod';
import { useForm, Form, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '../components/Form';
import { useGetPlantings, usePostHarvest } from '../helpers/farmQueries';
import { Input } from '../components/Input';
import { Textarea } from '../components/Textarea';
import { Button } from '../components/Button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/Select';
import { Popover, PopoverTrigger, PopoverContent } from '../components/Popover';
import { Calendar } from '../components/Calendar';
import { Calendar as CalendarIcon, DollarSign, Loader2, Mic, MicOff, Square } from 'lucide-react';
import { schema as postHarvestSchema } from '../endpoints/harvests_POST.schema';
import { toast } from 'sonner';
import styles from './harvest.module.css';

const formSchema = postHarvestSchema.extend({
  plantingId: z.string().min(1, "Please select a planting."),
});

type FormValues = z.infer<typeof formSchema>;

type SpeechRecognitionState = 'idle' | 'listening' | 'processing';

export default function HarvestPage() {
  const { data: plantings, isFetching: isFetchingPlantings } = useGetPlantings();
  const postHarvestMutation = usePostHarvest();

  const [speechState, setSpeechState] = useState<SpeechRecognitionState>('idle');
  const [currentSpeechField, setCurrentSpeechField] = useState<'pounds' | 'notes' | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const form = useForm({
    schema: formSchema,
    defaultValues: {
      plantingId: '',
      poundsHarvested: 0,
      harvestDate: new Date(),
      notes: '',
    },
  });

  const activePlantings = useMemo(() => {
    return plantings?.filter(p => p.isActive) ?? [];
  }, [plantings]);

  const selectedPlanting = useMemo(() => {
    if (!form.values.plantingId) return null;
    return activePlantings.find(p => p.id === parseInt(form.values.plantingId, 10));
  }, [form.values.plantingId, activePlantings]);

  const calculatedValue = useMemo(() => {
    if (!selectedPlanting || !form.values.poundsHarvested) return 0;
    return form.values.poundsHarvested * selectedPlanting.crop.pricePerPound;
  }, [selectedPlanting, form.values.poundsHarvested]);

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        setSpeechState('listening');
        toast.info('Listening...', { duration: 2000 });
      };

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        console.log('Speech recognition result:', transcript);
        
        if (currentSpeechField === 'pounds') {
          handlePoundsTranscript(transcript);
        } else if (currentSpeechField === 'notes') {
          handleNotesTranscript(transcript);
        }
        
        setSpeechState('idle');
        setCurrentSpeechField(null);
        toast.success('Speech recognized successfully!');
      };

      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setSpeechState('idle');
        setCurrentSpeechField(null);
        
        let errorMessage = 'Speech recognition failed';
        switch (event.error) {
          case 'no-speech':
            errorMessage = 'No speech detected. Please try again.';
            break;
          case 'not-allowed':
            errorMessage = 'Microphone access denied. Please allow microphone access.';
            break;
          case 'network':
            errorMessage = 'Network error. Please check your connection.';
            break;
          default:
            errorMessage = `Speech recognition error: ${event.error}`;
        }
        toast.error(errorMessage);
      };

      recognitionRef.current.onend = () => {
        if (speechState === 'listening') {
          setSpeechState('idle');
          setCurrentSpeechField(null);
        }
      };
    }
  }, [currentSpeechField, speechState]);

  const parseSpokenNumber = (transcript: string): number => {
    // Remove common filler words and clean up the transcript
    let cleaned = transcript.toLowerCase()
      .replace(/\b(pounds?|lbs?|pound)\b/g, '')
      .replace(/\b(and|point|decimal)\b/g, '.')
      .replace(/\b(zero|oh)\b/g, '0')
      .replace(/\bone\b/g, '1')
      .replace(/\btwo\b/g, '2')
      .replace(/\bthree\b/g, '3')
      .replace(/\bfour\b/g, '4')
      .replace(/\bfive\b/g, '5')
      .replace(/\bsix\b/g, '6')
      .replace(/\bseven\b/g, '7')
      .replace(/\beight\b/g, '8')
      .replace(/\bnine\b/g, '9')
      .replace(/\bten\b/g, '10')
      .replace(/\beleven\b/g, '11')
      .replace(/\btwelve\b/g, '12')
      .replace(/\bthirteen\b/g, '13')
      .replace(/\bfourteen\b/g, '14')
      .replace(/\bfifteen\b/g, '15')
      .replace(/\bsixteen\b/g, '16')
      .replace(/\bseventeen\b/g, '17')
      .replace(/\beighteen\b/g, '18')
      .replace(/\bnineteen\b/g, '19')
      .replace(/\btwenty\b/g, '20')
      .replace(/\bthirty\b/g, '30')
      .replace(/\bforty\b/g, '40')
      .replace(/\bfifty\b/g, '50')
      .replace(/\bsixty\b/g, '60')
      .replace(/\bseventy\b/g, '70')
      .replace(/\beighty\b/g, '80')
      .replace(/\bninety\b/g, '90')
      .replace(/\bhundred\b/g, '00')
      .trim();

    // Extract numbers from the cleaned transcript
    const numberMatch = cleaned.match(/(\d+(?:\.\d+)?)/);
    if (numberMatch) {
      return parseFloat(numberMatch[1]);
    }

    // If no direct number found, try to parse the original transcript as a number
    const directNumber = parseFloat(transcript);
    return isNaN(directNumber) ? 0 : directNumber;
  };

  const handlePoundsTranscript = (transcript: string) => {
    const pounds = parseSpokenNumber(transcript);
    console.log('Parsed pounds:', pounds, 'from transcript:', transcript);
    form.setValues(prev => ({ ...prev, poundsHarvested: pounds }));
  };

  const handleNotesTranscript = (transcript: string) => {
    const currentNotes = form.values.notes || '';
    const newNotes = currentNotes ? `${currentNotes} ${transcript}` : transcript;
    form.setValues(prev => ({ ...prev, notes: newNotes }));
  };

  const startSpeechRecognition = (field: 'pounds' | 'notes') => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition is not supported in this browser.');
      return;
    }

    if (speechState === 'listening') {
      stopSpeechRecognition();
      return;
    }

    setCurrentSpeechField(field);
    setSpeechState('listening');
    try {
      recognitionRef.current.start();
    } catch (error) {
      console.error('Failed to start speech recognition:', error);
      setSpeechState('idle');
      setCurrentSpeechField(null);
      toast.error('Failed to start speech recognition');
    }
  };

  const stopSpeechRecognition = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setSpeechState('idle');
    setCurrentSpeechField(null);
  };

  const getSpeechButtonIcon = (field: 'pounds' | 'notes') => {
    if (speechState === 'listening' && currentSpeechField === field) {
      return <Square size={16} className={styles.recordingIcon} />;
    }
    return speechState === 'idle' ? <Mic size={16} /> : <MicOff size={16} />;
  };

  const getSpeechButtonVariant = (field: 'pounds' | 'notes') => {
    if (speechState === 'listening' && currentSpeechField === field) {
      return 'destructive' as const;
    }
    return 'outline' as const;
  };

  const isSpeechSupported = typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);

  const onSubmit = (values: FormValues) => {
    const submissionData = {
      ...values,
      plantingId: parseInt(values.plantingId, 10),
      poundsHarvested: Number(values.poundsHarvested),
    };

    postHarvestMutation.mutate(submissionData, {
      onSuccess: () => {
        toast.success('Harvest recorded successfully!');
        form.setValues({
          plantingId: '',
          poundsHarvested: 0,
          harvestDate: new Date(),
          notes: '',
        });
      },
      onError: (error) => {
        console.error("Failed to record harvest:", error);
        toast.error('Failed to record harvest. Please try again.');
      },
    });
  };

  return (
    <>
      <Helmet>
        <title>Record Harvest - Hourglass Tree Farms</title>
        <meta name="description" content="Record a new harvest" />
      </Helmet>
      <div className={styles.page}>
        <div className={styles.container}>
          <header className={styles.header}>
            <h1 className={styles.title}>Record Harvest</h1>
            <p className={styles.subtitle}>Log a new harvest from one of your active plantings.</p>
            {isSpeechSupported && (
              <p className={styles.speechHint}>💬 Use the microphone buttons to speak your harvest data</p>
            )}
          </header>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className={styles.form}>
              <FormItem name="plantingId">
                <FormLabel>Planting</FormLabel>
                <Select
                  onValueChange={(value) => form.setValues(prev => ({ ...prev, plantingId: value }))}
                  value={form.values.plantingId}
                  disabled={isFetchingPlantings || postHarvestMutation.isPending}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a crop and row..." />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {activePlantings.map(p => (
                      <SelectItem key={p.id} value={String(p.id)}>
                        {p.crop.name} - Row {p.row.rowNumber} (Planted: {new Date(p.plantedDate).toLocaleDateString()})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>

              <div className={styles.grid}>
                <FormItem name="poundsHarvested">
                  <FormLabel>Pounds Harvested (lbs)</FormLabel>
                  <div className={styles.inputWithSpeech}>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="e.g., 50.5"
                        value={form.values.poundsHarvested}
                        onChange={(e) => form.setValues(prev => ({ ...prev, poundsHarvested: e.target.valueAsNumber || 0 }))}
                        disabled={postHarvestMutation.isPending}
                      />
                    </FormControl>
                    {isSpeechSupported && (
                      <Button
                        type="button"
                        size="icon-md"
                        variant={getSpeechButtonVariant('pounds')}
                        onClick={() => startSpeechRecognition('pounds')}
                        disabled={postHarvestMutation.isPending || (speechState === 'listening' && currentSpeechField !== 'pounds')}
                        className={styles.speechButton}
                      >
                        {getSpeechButtonIcon('pounds')}
                      </Button>
                    )}
                  </div>
                  {speechState === 'listening' && currentSpeechField === 'pounds' && (
                    <FormDescription className={styles.listeningText}>
                      🎙️ Listening for pounds... (say a number like "twenty five point five")
                    </FormDescription>
                  )}
                  <FormMessage />
                </FormItem>

                <FormItem name="harvestDate">
                  <FormLabel>Harvest Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={styles.dateButton}
                          disabled={postHarvestMutation.isPending}
                        >
                          {form.values.harvestDate ? new Date(form.values.harvestDate).toLocaleDateString() : <span>Pick a date</span>}
                          <CalendarIcon size={16} />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent removeBackgroundAndPadding>
                      <Calendar
                        mode="single"
                        selected={form.values.harvestDate}
                        onSelect={(date) => date && form.setValues(prev => ({ ...prev, harvestDate: date }))}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              </div>

              <FormItem name="notes">
                <FormLabel>Notes (Optional)</FormLabel>
                <div className={styles.inputWithSpeech}>
                  <FormControl>
                    <Textarea
                      placeholder="Any notes about this harvest..."
                      value={form.values.notes ?? ''}
                      onChange={(e) => form.setValues(prev => ({ ...prev, notes: e.target.value }))}
                      disabled={postHarvestMutation.isPending}
                    />
                  </FormControl>
                  {isSpeechSupported && (
                    <Button
                      type="button"
                      size="icon-md"
                      variant={getSpeechButtonVariant('notes')}
                      onClick={() => startSpeechRecognition('notes')}
                      disabled={postHarvestMutation.isPending || (speechState === 'listening' && currentSpeechField !== 'notes')}
                      className={styles.speechButton}
                    >
                      {getSpeechButtonIcon('notes')}
                    </Button>
                  )}
                </div>
                {speechState === 'listening' && currentSpeechField === 'notes' && (
                  <FormDescription className={styles.listeningText}>
                    🎙️ Listening for notes... (speak naturally about your harvest)
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>

              {calculatedValue > 0 && (
                <div className={styles.valueDisplay}>
                  <DollarSign size={20} className={styles.valueIcon} />
                  <div>
                    <p className={styles.valueLabel}>Estimated Value</p>
                    <p className={styles.valueAmount}>
                      ${calculatedValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              )}

              <Button type="submit" disabled={postHarvestMutation.isPending} className={styles.submitButton}>
                {postHarvestMutation.isPending && <Loader2 size={16} className={styles.spinner} />}
                {postHarvestMutation.isPending ? 'Saving...' : 'Record Harvest'}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </>
  );
}