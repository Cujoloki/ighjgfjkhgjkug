import React from 'react';
import { FarmSettingsPage } from '../components/FarmSettingsPage';
import styles from './settings.module.css';

export default function SettingsPage() {
  return (
    <div className={styles.container}>
      <FarmSettingsPage />
    </div>
  );
}