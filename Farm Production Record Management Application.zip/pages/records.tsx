import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useGetHarvests, useGetCrops, useGetRows } from '../helpers/farmQueries';
import { HarvestReportsPage } from '../components/HarvestReportsPage';
import { Skeleton } from '../components/Skeleton';
import { Input } from '../components/Input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/Select';
import { Popover, PopoverTrigger, PopoverContent } from '../components/Popover';
import { Calendar } from '../components/Calendar';
import { Button } from '../components/Button';
import { Calendar as CalendarIcon, X, Download, BarChart3, Table } from 'lucide-react';
import type { DateRange } from 'react-day-picker';
import * as XLSX from 'xlsx';
import styles from './records.module.css';

export default function RecordsPage() {
  const { data: harvests, isFetching: isFetchingHarvests } = useGetHarvests();
  const { data: crops, isFetching: isFetchingCrops } = useGetCrops();
  const { data: rows, isFetching: isFetchingRows } = useGetRows();

  const [activeTab, setActiveTab] = useState<'weekly' | 'detailed'>('weekly');
  const [cropFilter, setCropFilter] = useState<string>('all');
  const [rowFilter, setRowFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<DateRange | undefined>();

  const isLoading = isFetchingHarvests || isFetchingCrops || isFetchingRows;

  const exportToExcel = () => {
    if (!harvests || !crops || !rows) {
      console.error('Cannot export: data not loaded');
      return;
    }

    // Create Excel workbook
    const wb = XLSX.utils.book_new();

    // Prepare harvest data for export
    const exportData = harvests.map(harvest => {
      const crop = crops.find(c => c.id === harvest.planting?.crop?.id);
      const row = rows.find(r => r.id === harvest.planting?.row?.id);
      const harvestValue = Number(harvest.poundsHarvested) * Number(crop?.pricePerPound || 0);
      
      return {
        'Harvest Date': new Date(harvest.harvestDate).toLocaleDateString(),
        'Crop': crop?.name || 'Unknown',
        'Row': row ? `Row ${row.rowNumber}` : 'Unknown',
        'Pounds Harvested': Number(harvest.poundsHarvested),
        'Price per Pound': crop ? `$${Number(crop.pricePerPound).toFixed(2)}` : '$0.00',
        'Total Value': `$${harvestValue.toFixed(2)}`,
        'Notes': harvest.notes || ''
      };
    });

    // Add harvest data sheet
    const ws = XLSX.utils.json_to_sheet(exportData);
    XLSX.utils.book_append_sheet(wb, ws, 'Harvest Records');

    // Calculate summary data
    const totalPounds = harvests.reduce((sum, harvest) => sum + Number(harvest.poundsHarvested), 0);
    const totalValue = harvests.reduce((sum, harvest) => {
      const crop = crops.find(c => c.id === harvest.planting?.crop?.id);
      return sum + (Number(harvest.poundsHarvested) * Number(crop?.pricePerPound || 0));
    }, 0);

    // Add summary sheet
    const summaryData = [
      { Metric: 'Total Pounds Harvested', Value: totalPounds.toFixed(2) },
      { Metric: 'Total Harvest Value', Value: `$${totalValue.toFixed(2)}` },
      { Metric: 'Total Harvests Recorded', Value: harvests.length },
      { Metric: 'Export Date', Value: new Date().toLocaleDateString() }
    ];

    const summaryWs = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');

    // Generate filename with current date
    const filename = `hourglass-tree-farms-production-records-${new Date().toISOString().split('T')[0]}.xlsx`;
    
    // Save the file
    XLSX.writeFile(wb, filename);
  };

  return (
    <>
      <Helmet>
        <title>Production Records - Hourglass Tree Farms</title>
        <meta name="description" content="View comprehensive harvest reports and detailed production records" />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.header}>
          <div className={styles.headerContent}>
            <div>
              <h1 className={styles.title}>Production Records</h1>
              <p className={styles.subtitle}>
                Comprehensive harvest reports, weekly summaries, and detailed production records.
              </p>
            </div>
            <Button 
              onClick={exportToExcel} 
              disabled={isLoading || !harvests?.length}
              className={styles.exportButton}
            >
              <Download size={16} />
              Export to Excel
            </Button>
          </div>
        </header>

        <div className={styles.tabNavigation}>
          <Button
            variant={activeTab === 'weekly' ? 'primary' : 'ghost'}
            onClick={() => setActiveTab('weekly')}
            className={styles.tabButton}
          >
            <BarChart3 size={16} />
            Weekly Reports
          </Button>
          <Button
            variant={activeTab === 'detailed' ? 'primary' : 'ghost'}
            onClick={() => setActiveTab('detailed')}
            className={styles.tabButton}
          >
            <Table size={16} />
            Detailed Records
          </Button>
        </div>

        {activeTab === 'weekly' ? (
          <div className={styles.weeklyReportsContainer}>
            <HarvestReportsPage />
          </div>
        ) : (
          <div className={styles.detailedRecordsContainer}>
            {/* Detailed records content goes here */}
          </div>
        )}
      </div>
    </>
  );
}