import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { useGetRows, useGetHarvests } from '../helpers/farmQueries';
import { Button } from '../components/Button';
import { Skeleton } from '../components/Skeleton';
import { ArrowRight, PlusCircle, BookOpen } from 'lucide-react';
import styles from './_index.module.css';

const DashboardCard = ({
  title,
  value,
  description,
  isLoading,
  className,
}: {
  title: string;
  value: string | number;
  description: string;
  isLoading: boolean;
  className?: string;
}) => (
  <div className={`${styles.card} ${className || ''}`}>
    <h3 className={styles.cardTitle}>{title}</h3>
    {isLoading ? (
      <>
        <Skeleton style={{ height: '2.5rem', width: '60%', marginBottom: 'var(--spacing-2)' }} />
        <Skeleton style={{ height: '1rem', width: '80%' }} />
      </>
    ) : (
      <>
        <p className={styles.cardValue}>{value}</p>
        <p className={styles.cardDescription}>{description}</p>
      </>
    )}
  </div>
);

const RecentHarvests = () => {
  const { data: harvests, isFetching } = useGetHarvests();

  const recentHarvests = harvests
    ?.sort((a, b) => new Date(b.harvestDate).getTime() - new Date(a.harvestDate).getTime())
    .slice(0, 5);

  return (
    <div className={styles.card}>
      <h3 className={styles.cardTitle}>Recent Harvests</h3>
      {isFetching ? (
        <div className={styles.skeletonList}>
          {[...Array(5)].map((_, i) => (
            <div key={i} className={styles.skeletonItem}>
              <Skeleton style={{ height: '1.25rem', width: '40%' }} />
              <Skeleton style={{ height: '1rem', width: '20%' }} />
            </div>
          ))}
        </div>
      ) : (
        <ul className={styles.harvestList}>
          {recentHarvests && recentHarvests.length > 0 ? (
            recentHarvests.map((harvest) => (
              <li key={harvest.id} className={styles.harvestItem}>
                <span>
                  <strong>{harvest.planting.crop.name}</strong> from Row {harvest.planting.row.rowNumber}
                </span>
                <span className={styles.harvestAmount}>
                  {harvest.poundsHarvested.toLocaleString()} lbs
                </span>
              </li>
            ))
          ) : (
            <p className={styles.noData}>No harvests recorded yet.</p>
          )}
        </ul>
      )}
    </div>
  );
};

const TopCrops = () => {
    const { data: harvests, isFetching } = useGetHarvests();

    const topCrops = React.useMemo(() => {
        if (!harvests) return [];
        const cropTotals = harvests.reduce((acc, harvest) => {
            const cropName = harvest.planting.crop.name;
            const value = harvest.poundsHarvested * harvest.planting.crop.pricePerPound;
            if (!acc[cropName]) {
                acc[cropName] = 0;
            }
            acc[cropName] += value;
            return acc;
        }, {} as Record<string, number>);

        return Object.entries(cropTotals)
            .sort(([, a], [, b]) => b - a)
            .slice(0, 3)
            .map(([name, value]) => ({ name, value }));
    }, [harvests]);

    return (
        <div className={styles.card}>
            <h3 className={styles.cardTitle}>Top Crops by Value</h3>
            {isFetching ? (
                <div className={styles.skeletonList}>
                    {[...Array(3)].map((_, i) => (
                        <div key={i} className={styles.skeletonItem}>
                            <Skeleton style={{ height: '1.25rem', width: '50%' }} />
                            <Skeleton style={{ height: '1rem', width: '30%' }} />
                        </div>
                    ))}
                </div>
            ) : (
                <ul className={styles.harvestList}>
                    {topCrops.length > 0 ? (
                        topCrops.map((crop) => (
                            <li key={crop.name} className={styles.harvestItem}>
                                <span><strong>{crop.name}</strong></span>
                                <span className={styles.harvestAmount}>
                                    ${crop.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                            </li>
                        ))
                    ) : (
                        <p className={styles.noData}>No harvest data to calculate top crops.</p>
                    )}
                </ul>
            )}
        </div>
    );
};


export default function HomePage() {
  const { data: rows, isFetching: isFetchingRows } = useGetRows();
  const { data: harvests, isFetching: isFetchingHarvests } = useGetHarvests();

  const totalRows = rows?.length ?? 0;
  const activePlantings = rows?.filter(row => row.currentPlanting).length ?? 0;

  const totalValue = React.useMemo(() => {
    if (!harvests) return 0;
    return harvests.reduce((sum, harvest) => {
      return sum + (harvest.poundsHarvested * harvest.planting.crop.pricePerPound);
    }, 0);
  }, [harvests]);

  const isLoading = isFetchingRows || isFetchingHarvests;

  return (
    <>
      <Helmet>
        <title>Dashboard - Hourglass Tree Farms</title>
        <meta name="description" content="Farm production dashboard" />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.header}>
          <div>
            <h1 className={styles.title}>Dashboard</h1>
            <p className={styles.subtitle}>Welcome to your farm production overview.</p>
          </div>
          <div className={styles.actions}>
            <Button asChild variant="outline">
              <Link to="/records"><BookOpen size={16} /> View Records</Link>
            </Button>
            <Button asChild>
              <Link to="/harvest"><PlusCircle size={16} /> Record Harvest</Link>
            </Button>
          </div>
        </header>

        <div className={styles.grid}>
          <DashboardCard
            title="Total Harvest Value"
            value={`$${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            description="Total value of all recorded harvests."
            isLoading={isLoading}
          />
          <DashboardCard
            title="Active Plantings"
            value={`${activePlantings} / ${totalRows}`}
            description="Rows with an active crop planted."
            isLoading={isLoading}
          />
          <RecentHarvests />
          <TopCrops />
        </div>
      </div>
    </>
  );
}