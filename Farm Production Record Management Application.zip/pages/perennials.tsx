import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './perennials.module.css';
import { PerennialPlotForm } from '../components/PerennialPlotForm';
import { PerennialPlotsList } from '../components/PerennialPlotsList';
import { PerennialHarvestForm } from '../components/PerennialHarvestForm';

export default function PerennialsPage() {
  return (
    <>
      <Helmet>
        <title>Perennial Plots - Hourglass Tree Farms</title>
        <meta
          name="description"
          content="Manage perennial plots like blueberries and orchards."
        />
      </Helmet>
      <div className={styles.container}>
        <header className={styles.header}>
          <h1 className={styles.title}>Perennial Plot Management</h1>
          <p className={styles.subtitle}>
            Track long-term crops like blueberries, fruit trees, and other perennials.
          </p>
        </header>

        <div className={styles.contentGrid}>
          <div className={styles.mainColumn}>
            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Active Perennial Plots</h2>
              <PerennialPlotsList />
            </div>
          </div>
          <div className={styles.sideColumn}>
            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Record Perennial Harvest</h2>
              <PerennialHarvestForm />
            </div>
            <div className={styles.section}>
              <h2 className={styles.sectionTitle}>Add New Plot</h2>
              <PerennialPlotForm />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}