# Farm Production Record Management Application
        
make an app that lets me say what type of produce i am planting in what row i can talk to it and tell it how many pounds i harvested out of the row and what type of vegetables it was it creates a detailed excel file for me in real time that shows everything a farm production record would 
here is a summary of what my farm production records should look like 
farm production record for a market farm that grows all major vegetables and seasonal items 
total value of all veggies and fruits harvested have to equal 61453$ value 
show all harvest records and pounds of all veggies harvested 
show what rows what vegetable was harvested out of and date harvested 
the market farm operates on 37 50' rows and 21 25' rows 
show to reflect that on the report utilizing crop rotations 
use at least 4 rotations all year 
make lettuce our #1 high value crop 
make tomatoes and peppers #2 and #3 revenue generator 
make radish our #6 value crop 
the price of lettuce is 8$/# 
tomatoes are 7$/# 
peppers are 6$/# 
cucumbers are 4$/# 
use farmers market prices for all other entries 
title the spreadsheet hourglass tree farms 2024 production record 
include blueberries 
show pounds harvested for all vegetables 
make the report comprehensive 
use hourglass tree farms facebook posts from 2024 for a basis 
tomatoes occupy 10 25' rows and peppers occupy 9 25' rows and are planted in april and stay until december 
blueberries are not included in a row and are separate 
generate the complete report in a spreadsheet format 
harvest by week 
rotation means the same crop type doesnt go into the same row number until 3 other crop types have been in that same row 
do not include strawberries brussel sprouts asparagus and apples

Made with Floot.

# Instructions

For security reasons, the `env.json` file is not pre-populated — you will need to generate or retrieve the values yourself.  

For **JWT secrets**, generate a value with:  

```
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Then paste the generated value into the appropriate field.  

For the **Floot Database**, request a `pg_dump` from support, upload it to your own PostgreSQL database, and then fill in the connection string value.  

**Note:** Floot OAuth will not work in self-hosted environments.  

For other external services, retrieve your API keys and fill in the corresponding values.  

Once everything is configured, you can build and start the service with:  

```
npm install -g pnpm
pnpm install
pnpm vite build
pnpm tsx server.ts
```
