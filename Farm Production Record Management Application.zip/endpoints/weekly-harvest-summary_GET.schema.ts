import { z } from "zod";
import superjson from 'superjson';

// No input schema for a simple GET all
export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type CropBreakdown = {
  cropName: string;
  pounds: number;
  value: number;
};

export type WeeklySummary = {
  weekStartDate: Date;
  totalPounds: number;
  totalValue: number;
  cumulativePounds: number;
  cumulativeValue: number;
  cropBreakdown: CropBreakdown[];
};

export type OutputType = WeeklySummary[];

export const getWeeklyHarvestSummary = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/weekly-harvest-summary`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};