import { z } from "zod";
import { db } from '../helpers/db';
import { schema, OutputType } from './farm-settings_POST.schema';
import superjson from 'superjson';
import { SettingType } from '../helpers/farmSettingTypes';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const settingsToUpdate = schema.parse(json);

    if (settingsToUpdate.length === 0) {
      return new Response(superjson.stringify({ error: 'No settings provided for update.' }), { status: 400 });
    }

    await db.transaction().execute(async (trx) => {
      for (const setting of settingsToUpdate) {
        // Validate numeric types
        if (setting.settingType === 'number') {
          const parsed = z.number().safeParse(parseFloat(setting.settingValue));
          if (!parsed.success) {
            throw new Error(`Invalid number format for setting '${setting.settingKey}': ${setting.settingValue}`);
          }
        }

        const result = await trx
          .updateTable('farmSettings')
          .set({
            settingValue: setting.settingValue,
            updatedAt: new Date(),
          })
          .where('settingKey', '=', setting.settingKey)
          .executeTakeFirst();

        if (result.numUpdatedRows === 0n) {
          // Optionally, you could create the setting if it doesn't exist.
          // For now, we'll throw an error if an unknown key is provided.
          throw new Error(`Setting with key '${setting.settingKey}' not found.`);
        }
      }
    });

    return new Response(superjson.stringify({ success: true } satisfies OutputType), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error updating farm settings:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return new Response(superjson.stringify({ error: errorMessage }), { status: error instanceof z.ZodError ? 400 : 500 });
  }
}