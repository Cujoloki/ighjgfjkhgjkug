import { db } from "../helpers/db";
import { OutputType } from "./crops_GET.schema";
import superjson from 'superjson';
import { Selectable } from "kysely";
import { Crops } from "../helpers/schema";

export async function handle(request: Request) {
  try {
    const crops = await db.selectFrom('crops').selectAll().orderBy('name', 'asc').execute();
    
    const output: OutputType = crops.map(crop => ({
      ...crop,
      pricePerPound: Number(crop.pricePerPound)
    }));

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error fetching crops:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}