import { db } from "../helpers/db";
import { schema, OutputType } from "./plantings_POST.schema";
import superjson from 'superjson';
import { Transaction } from "kysely";
import { DB } from "../helpers/schema";
import { canPlantCropInRow } from "../helpers/cropRotation";
import { getPlantings } from "./plantings_GET.schema";

async function createPlanting(
  input: { cropId: number; rowId: number; plantedDate: Date; notes?: string | null },
  trx: Transaction<DB>
) {
  // Deactivate any existing planting in the same row
  await trx
    .updateTable('plantings')
    .set({ isActive: false, removedDate: new Date() })
    .where('rowId', '=', input.rowId)
    .where('isActive', '=', true)
    .execute();

  // Create the new planting
  const newPlanting = await trx
    .insertInto('plantings')
    .values({
      cropId: input.cropId,
      rowId: input.rowId,
      plantedDate: input.plantedDate,
      notes: input.notes ?? null,
      isActive: true,
    })
    .returningAll()
    .executeTakeFirstOrThrow();
  
  return newPlanting;
}

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    // Get current plantings data for rotation validation
    const plantingsData = await db
      .selectFrom('plantings')
      .leftJoin('crops', 'plantings.cropId', 'crops.id')
      .leftJoin('farmRows', 'plantings.rowId', 'farmRows.id')
      .select([
        'plantings.id',
        'plantings.plantedDate',
        'plantings.removedDate',
        'plantings.notes',
        'plantings.isActive',
        'plantings.createdAt',
        'crops.id as cropId',
        'crops.name as cropName',
        'crops.pricePerPound as cropPricePerPound',
        'crops.createdAt as cropCreatedAt',
        'farmRows.id as rowId',
        'farmRows.rowNumber',
        'farmRows.rowLength',
        'farmRows.createdAt as rowCreatedAt',
      ])
      .execute();

    // Transform the data to match the expected format for rotation validation
    const plantingsWithDetails = plantingsData
      .filter(p => p.cropId && p.rowId)
      .map(p => ({
        id: p.id,
        plantedDate: p.plantedDate,
        removedDate: p.removedDate,
        notes: p.notes,
        isActive: p.isActive,
        createdAt: p.createdAt,
        crop: {
          id: p.cropId!,
          name: p.cropName!,
          pricePerPound: Number(p.cropPricePerPound!),
          createdAt: p.cropCreatedAt!,
        },
        row: {
          id: p.rowId!,
          rowNumber: p.rowNumber!,
          rowLength: p.rowLength!,
          createdAt: p.rowCreatedAt!,
        },
      }));

    // Validate crop rotation rules
    const rotationCheck = canPlantCropInRow(plantingsWithDetails, input.rowId, input.cropId);
    
    if (!rotationCheck.canPlant) {
      console.log(`Crop rotation validation failed: ${rotationCheck.reason}`);
      return new Response(
        superjson.stringify({ 
          error: `Crop Rotation Rule Violation: ${rotationCheck.reason} This follows the 3-crop rotation rule where each crop must wait for 3 different crops to be planted in the same row before it can be replanted.`
        }), 
        { status: 400 }
      );
    }

    const newPlanting = await db.transaction().execute(async (trx) => {
      return createPlanting(input, trx);
    });

    console.log(`Successfully created planting for crop ${input.cropId} in row ${input.rowId}`);
    return new Response(superjson.stringify(newPlanting satisfies OutputType));
  } catch (error) {
    console.error("Error creating planting:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}