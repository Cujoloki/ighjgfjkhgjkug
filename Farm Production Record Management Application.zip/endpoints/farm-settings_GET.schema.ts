import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { FarmSettings } from '../helpers/schema';
import { SettingType } from '../helpers/farmSettingTypes';

export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type FarmSetting = Omit<Selectable<FarmSettings>, 'settingValue' | 'settingType'> & {
  settingValue: string | number;
  settingType: SettingType;
};

export type OutputType = FarmSetting[];

export const getFarmSettings = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/farm-settings`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};