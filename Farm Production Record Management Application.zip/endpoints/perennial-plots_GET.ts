import { db } from "../helpers/db";
import { OutputType } from "./perennial-plots_GET.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const plots = await db
      .selectFrom('perennialPlots')
      .selectAll()
      .orderBy('createdAt', 'desc')
      .execute();

    const output: OutputType = plots.map(plot => ({
      ...plot,
      plotSizeSqft: Number(plot.plotSizeSqft),
    }));

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error fetching perennial plots:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}