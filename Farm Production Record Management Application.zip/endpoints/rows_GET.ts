import { db } from "../helpers/db";
import { OutputType } from "./rows_GET.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const rowsWithPlantings = await db
      .selectFrom('farmRows')
      .leftJoin(
        (eb) =>
          eb
            .selectFrom('plantings')
            .select(['plantings.rowId', 'plantings.cropId', 'plantings.plantedDate', 'plantings.id as plantingId'])
            .where('plantings.isActive', '=', true)
            .as('activePlanting'),
        (join) => join.onRef('activePlanting.rowId', '=', 'farmRows.id')
      )
      .leftJoin('crops', 'crops.id', 'activePlanting.cropId')
      .select([
        'farmRows.id',
        'farmRows.rowNumber',
        'farmRows.rowLength',
        'farmRows.createdAt',
        'activePlanting.plantingId',
        'activePlanting.plantedDate',
        'crops.id as cropId',
        'crops.name as cropName',
        'crops.pricePerPound as cropPricePerPound',
      ])
      .orderBy('farmRows.rowNumber', 'asc')
      .execute();

    const output: OutputType = rowsWithPlantings.map(row => ({
      id: row.id,
      rowNumber: row.rowNumber,
      rowLength: row.rowLength,
      createdAt: row.createdAt,
      currentPlanting: row.plantingId ? {
        plantingId: row.plantingId,
        plantedDate: row.plantedDate!,
        crop: {
          id: row.cropId!,
          name: row.cropName!,
          pricePerPound: Number(row.cropPricePerPound!),
        }
      } : null
    }));

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error fetching farm rows:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}