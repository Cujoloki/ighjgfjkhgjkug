import { db } from "../helpers/db";
import { OutputType, WeeklySummary } from "./weekly-harvest-summary_GET.schema";
import superjson from 'superjson';
import { sql } from 'kysely';

type HarvestQueryResult = {
  weekStartDate: Date;
  cropName: string;
  totalPounds: string; // Kysely returns numeric/decimal as string
  totalValue: string;  // Kysely returns numeric/decimal as string
};

export async function handle(request: Request) {
  try {
    // This query unites annual and perennial harvests, groups them by week and crop,
    // and calculates total pounds and value for each group.
    const combinedHarvests = await db
      .selectFrom(
        (eb) => eb.selectFrom('harvests')
          .innerJoin('plantings', 'plantings.id', 'harvests.plantingId')
          .innerJoin('crops', 'crops.id', 'plantings.cropId')
          .select([
            'harvests.harvestDate as harvest_date',
            'crops.name as crop_name',
            'harvests.poundsHarvested as pounds_harvested',
            sql<string>`(harvests.pounds_harvested * crops.price_per_pound)::text`.as('total_value')
          ])
          .unionAll(
            eb.selectFrom('perennialHarvests')
              .innerJoin('perennialPlots', 'perennialPlots.id', 'perennialHarvests.perennialPlotId')
              .select([
                'perennialHarvests.harvestDate as harvest_date',
                'perennialPlots.cropType as crop_name',
                'perennialHarvests.poundsHarvested as pounds_harvested',
                sql<string>`coalesce(perennial_harvests.total_value, 0)::text`.as('total_value')
              ])
          ).as('all_harvests')
      )
      .select([
        sql<Date>`date_trunc('week', harvest_date)`.as('weekStartDate'),
        'crop_name as cropName',
        sql<string>`sum(pounds_harvested)`.as('totalPounds'),
        sql<string>`sum(total_value::numeric)`.as('totalValue')
      ])
      .groupBy(['weekStartDate', 'cropName'])
      .orderBy('weekStartDate', 'asc')
      .execute() as HarvestQueryResult[];

    // Process the flat query result into a nested structure grouped by week.
    const weeklyData: Record<string, WeeklySummary> = {};

    for (const row of combinedHarvests) {
      const weekKey = row.weekStartDate.toISOString();
      if (!weeklyData[weekKey]) {
        weeklyData[weekKey] = {
          weekStartDate: row.weekStartDate,
          totalPounds: 0,
          totalValue: 0,
          cropBreakdown: [],
          // Cumulative values will be calculated in the next step
          cumulativePounds: 0,
          cumulativeValue: 0,
        };
      }

      const pounds = Number(row.totalPounds);
      const value = Number(row.totalValue);

      weeklyData[weekKey].totalPounds += pounds;
      weeklyData[weekKey].totalValue += value;
      weeklyData[weekKey].cropBreakdown.push({
        cropName: row.cropName,
        pounds: pounds,
        value: value,
      });
    }

    // Sort the weekly summaries and calculate cumulative totals.
    const sortedWeeks = Object.values(weeklyData).sort(
      (a, b) => a.weekStartDate.getTime() - b.weekStartDate.getTime()
    );

    let cumulativePounds = 0;
    let cumulativeValue = 0;

    const finalOutput: OutputType = sortedWeeks.map(week => {
      cumulativePounds += week.totalPounds;
      cumulativeValue += week.totalValue;
      // Sort crop breakdown by value for consistent display
      week.cropBreakdown.sort((a, b) => b.value - a.value);
      return {
        ...week,
        cumulativePounds,
        cumulativeValue,
      };
    });

    return new Response(superjson.stringify(finalOutput));
  } catch (error) {
    console.error("Error fetching weekly harvest summary:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}