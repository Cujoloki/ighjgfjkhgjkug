import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { FarmRows, Crops } from '../helpers/schema';

// No input schema for a simple GET all
export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type RowWithPlanting = Selectable<FarmRows> & {
  currentPlanting: {
    plantingId: number;
    plantedDate: Date;
    crop: {
      id: number;
      name: string;
      pricePerPound: number;
    };
  } | null;
};

export type OutputType = RowWithPlanting[];

export const getRows = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/rows`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};