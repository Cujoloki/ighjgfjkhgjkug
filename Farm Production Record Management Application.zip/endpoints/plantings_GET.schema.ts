import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { Plantings, Crops, FarmRows } from '../helpers/schema';

// No input schema for a simple GET all
export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

type CropInfo = Omit<Selectable<Crops>, 'pricePerPound'> & {
  pricePerPound: number;
};

export type PlantingWithDetails = Omit<Selectable<Plantings>, 'cropId' | 'rowId'> & {
  crop: CropInfo;
  row: Selectable<FarmRows>;
};

export type OutputType = PlantingWithDetails[];

export const getPlantings = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/plantings`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};