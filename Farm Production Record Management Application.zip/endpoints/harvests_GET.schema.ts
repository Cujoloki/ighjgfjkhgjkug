import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { Harvests } from '../helpers/schema';

// No input schema for a simple GET all
export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type HarvestWithDetails = Omit<Selectable<Harvests>, 'plantingId' | 'poundsHarvested'> & {
  poundsHarvested: number;
  planting: {
    id: number;
    crop: {
      id: number;
      name: string;
      pricePerPound: number;
    };
    row: {
      id: number;
      rowNumber: number;
    };
  };
};

export type OutputType = HarvestWithDetails[];

export const getHarvests = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/harvests`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};