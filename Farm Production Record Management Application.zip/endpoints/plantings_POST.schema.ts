import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { Plantings } from '../helpers/schema';

export const schema = z.object({
  cropId: z.number().int().positive(),
  rowId: z.number().int().positive(),
  plantedDate: z.date(),
  notes: z.string().nullable().optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = Selectable<Plantings>;

export const postPlantings = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/plantings`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};