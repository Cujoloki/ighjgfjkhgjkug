import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { PerennialHarvests } from '../helpers/schema';

export const schema = z.object({
  perennialPlotId: z.number().int().positive(),
  harvestDate: z.date(),
  poundsHarvested: z.number().positive(),
  pricePerPound: z.number().positive(),
  harvestNotes: z.string().nullable().optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = Omit<Selectable<PerennialHarvests>, 'poundsHarvested' | 'pricePerPound' | 'totalValue'> & {
    poundsHarvested: number;
    pricePerPound: number;
    totalValue: number;
};

export const postPerennialHarvest = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/perennial-harvests`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};