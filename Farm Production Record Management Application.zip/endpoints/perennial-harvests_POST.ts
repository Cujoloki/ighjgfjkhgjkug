import { db } from "../helpers/db";
import { schema, OutputType } from "./perennial-harvests_POST.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const totalValue = input.poundsHarvested * input.pricePerPound;

    const newHarvest = await db
      .insertInto('perennialHarvests')
      .values({
        perennialPlotId: input.perennialPlotId,
        harvestDate: input.harvestDate,
        poundsHarvested: input.poundsHarvested,
        pricePerPound: input.pricePerPound,
        harvestNotes: input.harvestNotes,
        totalValue: totalValue,
      })
      .returningAll()
      .executeTakeFirstOrThrow();

    const output: OutputType = {
        ...newHarvest,
        poundsHarvested: Number(newHarvest.poundsHarvested),
        pricePerPound: Number(newHarvest.pricePerPound),
        totalValue: newHarvest.totalValue ? Number(newHarvest.totalValue) : 0,
    };

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error creating perennial harvest:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}