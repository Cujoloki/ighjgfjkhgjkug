import { db } from "../../helpers/db";
import { schema, OutputType } from "./delete_POST.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const { id } = schema.parse(json);

    // Check for active plantings before deleting
    const activePlanting = await db
      .selectFrom('plantings')
      .where('rowId', '=', id)
      .where('isActive', '=', true)
      .select('id')
      .executeTakeFirst();

    if (activePlanting) {
      return new Response(superjson.stringify({ error: "Cannot delete a row with an active planting. Please remove the planting first." }), { status: 409 }); // 409 Conflict
    }

    const result = await db
      .deleteFrom('farmRows')
      .where('id', '=', id)
      .returning('id')
      .executeTakeFirstOrThrow();

    return new Response(superjson.stringify({ success: true, id: result.id } satisfies OutputType));
  } catch (error) {
    console.error("Error deleting farm row:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}