import { db } from "../helpers/db";
import { schema, OutputType } from "./rows_POST.schema";
import superjson from 'superjson';
import { sql, Transaction } from 'kysely';
import { DB } from "../helpers/schema";

async function createSingleRow(rowNumber: number, rowLength: number, trx: Transaction<DB>) {
  return await trx
    .insertInto('farmRows')
    .values({ rowNumber, rowLength })
    .returningAll()
    .executeTakeFirstOrThrow();
}

async function createBatchRows(count: number, rowLength: number, trx: Transaction<DB>) {
  const maxRowResult = await trx
    .selectFrom('farmRows')
    .select(db.fn.max('rowNumber').as('maxRowNumber'))
    .executeTakeFirst();

  let startRowNumber = (maxRowResult?.maxRowNumber || 0) + 1;

  const rowsToInsert = [];
  for (let i = 0; i < count; i++) {
    rowsToInsert.push({
      rowNumber: startRowNumber++,
      rowLength: rowLength,
    });
  }

  if (rowsToInsert.length === 0) {
    return [];
  }

  return await trx
    .insertInto('farmRows')
    .values(rowsToInsert)
    .returningAll()
    .execute();
}

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const newRows = await db.transaction().execute(async (trx) => {
      if (input.type === 'single') {
        const existingRow = await trx.selectFrom('farmRows').where('rowNumber', '=', input.rowNumber).select('id').executeTakeFirst();
        if (existingRow) {
          throw new Error(`Row number ${input.rowNumber} already exists.`);
        }
        return [await createSingleRow(input.rowNumber, input.rowLength, trx)];
      } else { // batch
        return await createBatchRows(input.count, input.rowLength, trx);
      }
    });

    return new Response(superjson.stringify(newRows satisfies OutputType));
  } catch (error) {
    console.error("Error creating farm row(s):", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}