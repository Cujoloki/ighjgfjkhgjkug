import { db } from "../helpers/db";
import { OutputType } from "./harvests_GET.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const harvests = await db
      .selectFrom('harvests')
      .innerJoin('plantings', 'plantings.id', 'harvests.plantingId')
      .innerJoin('crops', 'crops.id', 'plantings.cropId')
      .innerJoin('farmRows', 'farmRows.id', 'plantings.rowId')
      .select([
        'harvests.id',
        'harvests.harvestDate',
        'harvests.poundsHarvested',
        'harvests.notes',
        'harvests.createdAt',
        'plantings.id as plantingId',
        'crops.id as cropId',
        'crops.name as cropName',
        'crops.pricePerPound as cropPricePerPound',
        'farmRows.id as rowId',
        'farmRows.rowNumber',
      ])
      .orderBy('harvests.harvestDate', 'desc')
      .execute();

    const output: OutputType = harvests.map(h => ({
      id: h.id,
      harvestDate: h.harvestDate,
      poundsHarvested: Number(h.poundsHarvested),
      notes: h.notes,
      createdAt: h.createdAt,
      planting: {
        id: h.plantingId,
        crop: {
          id: h.cropId,
          name: h.cropName,
          pricePerPound: Number(h.cropPricePerPound),
        },
        row: {
          id: h.rowId,
          rowNumber: h.rowNumber,
        }
      }
    }));

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error fetching harvests:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}