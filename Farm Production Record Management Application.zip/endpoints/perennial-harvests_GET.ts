import { db } from "../helpers/db";
import { OutputType } from "./perennial-harvests_GET.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const harvests = await db
      .selectFrom('perennialHarvests')
      .innerJoin('perennialPlots', 'perennialPlots.id', 'perennialHarvests.perennialPlotId')
      .select([
        'perennialHarvests.id',
        'perennialHarvests.harvestDate',
        'perennialHarvests.poundsHarvested',
        'perennialHarvests.pricePerPound',
        'perennialHarvests.totalValue',
        'perennialHarvests.harvestNotes',
        'perennialHarvests.createdAt',
        'perennialPlots.id as plotId',
        'perennialPlots.plotName',
        'perennialPlots.cropType',
      ])
      .orderBy('perennialHarvests.harvestDate', 'desc')
      .execute();

    const output: OutputType = harvests.map(h => ({
      id: h.id,
      harvestDate: h.harvestDate,
      poundsHarvested: Number(h.poundsHarvested),
      pricePerPound: Number(h.pricePerPound),
      totalValue: h.totalValue ? Number(h.totalValue) : 0,
      harvestNotes: h.harvestNotes,
      createdAt: h.createdAt,
      plot: {
        id: h.plotId,
        plotName: h.plotName,
        cropType: h.cropType,
      }
    }));

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error fetching perennial harvests:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}