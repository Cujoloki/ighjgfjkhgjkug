import { db } from "../helpers/db";
import { schema, OutputType } from "./perennial-plots_POST.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const newPlot = await db
      .insertInto('perennialPlots')
      .values({
        plotName: input.plotName,
        cropType: input.cropType,
        plantedDate: input.plantedDate,
        plotSizeSqft: input.plotSizeSqft,
        expectedProductiveYears: input.expectedProductiveYears,
        locationDescription: input.locationDescription,
        maintenanceNotes: input.maintenanceNotes,
        isActive: true,
      })
      .returningAll()
      .executeTakeFirstOrThrow();

    const output: OutputType = {
      ...newPlot,
      plotSizeSqft: Number(newPlot.plotSizeSqft),
    };

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error creating perennial plot:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}