import { db } from "../helpers/db";
import { OutputType, PlotWithRows } from "./plots_GET.schema";
import superjson from 'superjson';
import { jsonObjectFrom } from 'kysely/helpers/postgres';

export async function handle(request: Request) {
  try {
    const plots = await db
      .selectFrom('plots')
      .selectAll('plots')
      .select((eb) => [
        jsonObjectFrom(
          eb.selectFrom('plotRows')
            .innerJoin('farmRows', 'farmRows.id', 'plotRows.rowId')
            .select(['farmRows.id', 'farmRows.rowNumber', 'farmRows.rowLength'])
            .whereRef('plotRows.plotId', '=', 'plots.id')
            .orderBy('farmRows.rowNumber')
        ).as('rows')
      ])
      .orderBy('plots.createdAt', 'desc')
      .execute();

    // The jsonObjectFrom helper returns a string, so we need to parse it.
    // It also returns an array of objects, but we want to aggregate them into a single array of rows.
    // A better approach is to use json_agg. Let's correct this.
    
    const plotsWithRows = await db
      .selectFrom('plots')
      .selectAll('plots')
      .select((eb) => [
        eb.fn.coalesce(
          (
            eb.selectFrom('plotRows')
              .innerJoin('farmRows', 'farmRows.id', 'plotRows.rowId')
              .select(eb.fn.jsonAgg(
                eb.fn.jsonBuildObject({
                  id: eb.ref('farmRows.id'),
                  rowNumber: eb.ref('farmRows.rowNumber'),
                  rowLength: eb.ref('farmRows.rowLength')
                })
              ).as('aggregatedRows'))
              .whereRef('plotRows.plotId', '=', 'plots.id')
          ),
          '[]'::any // Kysely requires type casting for json empty array default
        ).as('rows')
      ])
      .orderBy('plots.name', 'asc')
      .execute();

    const output: OutputType = plotsWithRows.map(p => ({
      ...p,
      rows: p.rows as PlotWithRows['rows'] // Cast from unknown
    }));

    return new Response(superjson.stringify(output));
  } catch (error) {
    console.error("Error fetching plots:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}