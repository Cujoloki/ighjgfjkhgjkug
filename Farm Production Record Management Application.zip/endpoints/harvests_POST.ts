import { db } from "../helpers/db";
import { schema, OutputType } from "./harvests_POST.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const newHarvest = await db
      .insertInto('harvests')
      .values({
        plantingId: input.plantingId,
        harvestDate: input.harvestDate,
        poundsHarvested: input.poundsHarvested,
        notes: input.notes,
      })
      .returningAll()
      .executeTakeFirstOrThrow();

    const output: OutputType = {
        ...newHarvest,
        poundsHarvested: Number(newHarvest.poundsHarvested)
    }

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error creating harvest:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}