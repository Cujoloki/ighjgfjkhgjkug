import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { PerennialPlots } from '../helpers/schema';

export const schema = z.object({
  plotName: z.string().min(1, "Plot name is required."),
  cropType: z.string().min(1, "Crop type is required."),
  plantedDate: z.date(),
  plotSizeSqft: z.number().positive("Plot size must be a positive number."),
  expectedProductiveYears: z.number().int().positive().optional().nullable(),
  locationDescription: z.string().optional().nullable(),
  maintenanceNotes: z.string().optional().nullable(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = Omit<Selectable<PerennialPlots>, 'plotSizeSqft'> & {
  plotSizeSqft: number;
};

export const postPerennialPlot = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/perennial-plots`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};