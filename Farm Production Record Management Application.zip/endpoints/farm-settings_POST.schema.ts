import { z } from "zod";
import superjson from 'superjson';
import { SettingTypeSchema } from '../helpers/farmSettingTypes';

export const settingSchema = z.object({
  settingKey: z.string(),
  settingValue: z.string(), // All form values come as strings, validation happens on the backend
  settingType: SettingTypeSchema,
});

export const schema = z.array(settingSchema);

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  success: boolean;
};

export const postFarmSettings = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/farm-settings`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};