import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from 'kysely';
import type { FarmRows } from '../helpers/schema';

const singleRowSchema = z.object({
  type: z.literal('single'),
  rowNumber: z.number().int().positive("Row number must be a positive integer."),
  rowLength: z.number().positive("Row length must be a positive number."),
});

const batchRowSchema = z.object({
  type: z.literal('batch'),
  count: z.number().int().min(1, "Must create at least one row.").max(100, "Cannot create more than 100 rows at once."),
  rowLength: z.number().positive("Row length must be a positive number."),
});

export const schema = z.discriminatedUnion("type", [
  singleRowSchema,
  batchRowSchema,
]);

export type InputType = z.infer<typeof schema>;

export type OutputType = Selectable<FarmRows>[];

export const postRows = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/rows`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text()) as { error: string };
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};