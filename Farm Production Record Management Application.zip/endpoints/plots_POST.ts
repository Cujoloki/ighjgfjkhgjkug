import { db } from "../helpers/db";
import { schema, OutputType } from "./plots_POST.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const newPlot = await db
      .insertInto('plots')
      .values({
        name: input.name,
        description: input.description,
        color: input.color,
      })
      .returningAll()
      .executeTakeFirstOrThrow();

    return new Response(superjson.stringify(newPlot satisfies OutputType));
  } catch (error) {
    console.error("Error creating plot:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}