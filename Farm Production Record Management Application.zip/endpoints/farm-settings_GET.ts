import { db } from '../helpers/db';
import { OutputType } from './farm-settings_GET.schema';
import { SettingType } from '../helpers/farmSettingTypes';
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const settings = await db.selectFrom('farmSettings').selectAll().execute();

    const output: OutputType = settings.map(setting => {
      let value: string | number = setting.settingValue;
      const settingType = setting.settingType as SettingType;
      if (settingType === 'number') {
        const parsedNumber = parseFloat(setting.settingValue);
        value = isNaN(parsedNumber) ? 0 : parsedNumber;
      }
      return {
        ...setting,
        settingType,
        settingValue: value,
      };
    });

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error fetching farm settings:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}