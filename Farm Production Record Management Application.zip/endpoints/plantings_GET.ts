import { db } from "../helpers/db";
import { OutputType } from "./plantings_GET.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const plantings = await db
      .selectFrom('plantings')
      .innerJoin('crops', 'crops.id', 'plantings.cropId')
      .innerJoin('farmRows', 'farmRows.id', 'plantings.rowId')
      .select([
        'plantings.id',
        'plantings.plantedDate',
        'plantings.removedDate',
        'plantings.isActive',
        'plantings.notes',
        'plantings.createdAt',
        'crops.id as cropId',
        'crops.name as cropName',
        'crops.pricePerPound as cropPricePerPound',
        'crops.createdAt as cropCreatedAt',
        'farmRows.id as rowId',
        'farmRows.rowNumber',
        'farmRows.rowLength',
        'farmRows.createdAt as rowCreatedAt',
      ])
      .orderBy('plantings.plantedDate', 'desc')
      .execute();

    const output: OutputType = plantings.map(p => ({
      id: p.id,
      plantedDate: p.plantedDate,
      removedDate: p.removedDate,
      isActive: p.isActive,
      notes: p.notes,
      createdAt: p.createdAt,
      crop: {
        id: p.cropId,
        name: p.cropName,
        pricePerPound: Number(p.cropPricePerPound),
        createdAt: p.cropCreatedAt,
      },
      row: {
        id: p.rowId,
        rowNumber: p.rowNumber,
        rowLength: p.rowLength,
        createdAt: p.rowCreatedAt,
      }
    }));

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error) {
    console.error("Error fetching plantings:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 500 });
  }
}