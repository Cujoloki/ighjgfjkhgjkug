import { db } from "../../helpers/db";
import { schema } from "./delete_POST.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const { id } = schema.parse(json);

    await db.transaction().execute(async (trx) => {
      // First, remove all row associations for this plot
      await trx
        .deleteFrom('plotRows')
        .where('plotId', '=', id)
        .execute();

      // Then, delete the plot itself
      const result = await trx
        .deleteFrom('plots')
        .where('id', '=', id)
        .executeTakeFirst();
      
      if (result.numDeletedRows === 0n) {
        throw new Error("Plot not found or already deleted.");
      }
    });

    return new Response(superjson.stringify({ success: true }));
  } catch (error) {
    console.error("Error deleting plot:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: errorMessage }), { status: 400 });
  }
}