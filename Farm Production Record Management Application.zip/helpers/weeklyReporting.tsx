import { useQuery } from '@tanstack/react-query';
import { getWeeklyHarvestSummary } from '../endpoints/weekly-harvest-summary_GET.schema';

export const weeklyReportingQueryKeys = {
  summary: ['weeklyHarvestSummary'] as const,
};

/**
 * React Query hook to fetch the weekly harvest summary data.
 * This data combines both annual and perennial harvests.
 */
export const useGetWeeklyHarvestSummary = () => {
  return useQuery({
    queryKey: weeklyReportingQueryKeys.summary,
    queryFn: () => getWeeklyHarvestSummary(),
  });
};