import { z } from "zod";

/**
 * Defines the allowed types for a farm setting's value.
 * This ensures that settings are consistently handled as either text or numbers.
 */
export const SettingTypeSchema = z.union([
  z.literal("text"),
  z.literal("number"),
]);

export type SettingType = z.infer<typeof SettingTypeSchema>;

/**
 * Zod schema for a single farm setting.
 * This schema is based on the `FarmSettings` table from the database schema.
 * It is used for data validation in both frontend components and backend endpoints.
 */
export const FarmSettingSchema = z.object({
  id: z.number(),
  settingKey: z.string().min(1, { message: "Setting key is required." }),
  settingValue: z.string().min(1, { message: "Setting value is required." }),
  settingType: SettingTypeSchema,
  description: z.string().nullable(),
  createdAt: z.date().nullable(),
  updatedAt: z.date().nullable(),
});

export type FarmSetting = z.infer<typeof FarmSettingSchema>;

/**
 * Zod schema for creating a new farm setting.
 * It omits database-generated fields like `id`, `createdAt`, and `updatedAt`.
 */
export const CreateFarmSettingSchema = FarmSettingSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type CreateFarmSetting = z.infer<typeof CreateFarmSettingSchema>;

/**
 * Zod schema for updating an existing farm setting.
 * All fields are optional, allowing for partial updates.
 * It omits database-generated fields.
 */
export const UpdateFarmSettingSchema = CreateFarmSettingSchema.partial();

export type UpdateFarmSetting = z.infer<typeof UpdateFarmSettingSchema>;