import type { PlantingWithDetails } from '../endpoints/plantings_GET.schema';
import type { OutputType as CropsOutput } from '../endpoints/crops_GET.schema';

type CropInfo = CropsOutput[number];

/**
 * Retrieves the historical sequence of crops planted in a specific row.
 * It filters for completed plantings (those with a `removedDate`) and sorts them chronologically.
 *
 * @param plantings - An array of all planting details.
 * @param rowId - The ID of the row to get the history for.
 * @returns An array of CropType objects representing the rotation history.
 */
export function getRotationHistoryForRow(
  plantings: PlantingWithDetails[],
  rowId: number,
): CropInfo[] {
  return plantings
    .filter(p => p.row.id === rowId && p.removedDate)
    .sort((a, b) => new Date(a.removedDate!).getTime() - new Date(b.removedDate!).getTime())
    .map(p => p.crop);
}

/**
 * Validates if a specific crop can be planted in a given row based on rotation rules.
 * The rule is that a crop cannot be replanted until at least 3 other distinct crops
 * have been grown in that row since its last appearance.
 *
 * @param plantings - An array of all planting details.
 * @param rowId - The ID of the row to check.
 * @param cropId - The ID of the crop to be planted.
 * @returns An object with a boolean `canPlant` and an optional `reason` string if it cannot be planted.
 */
export function canPlantCropInRow(
  plantings: PlantingWithDetails[],
  rowId: number,
  cropId: number,
): { canPlant: boolean; reason?: string } {
  const history = getRotationHistoryForRow(plantings, rowId);
  const lastIndexOfCrop = history.map(c => c.id).lastIndexOf(cropId);

  if (lastIndexOfCrop === -1) {
    // Crop has never been planted in this row, so it's allowed.
    return { canPlant: true };
  }

  // Get the unique crops planted since the last time this crop was planted.
  const subsequentCrops = history.slice(lastIndexOfCrop + 1);
  const uniqueSubsequentCrops = new Map<number, CropInfo>();
  subsequentCrops.forEach(crop => {
    if (!uniqueSubsequentCrops.has(crop.id)) {
      uniqueSubsequentCrops.set(crop.id, crop);
    }
  });

  if (uniqueSubsequentCrops.size < 3) {
    const cropName = history[lastIndexOfCrop].name;
    const needed = 3 - uniqueSubsequentCrops.size;
    return {
      canPlant: false,
      reason: `Cannot plant ${cropName} yet. Only ${uniqueSubsequentCrops.size} unique crops have been planted since its last rotation. Need ${needed} more.`,
    };
  }

  return { canPlant: true };
}

/**
 * Determines the rotation status for a given row and a potential crop.
 *
 * @param plantings - An array of all planting details.
 * @param rowId - The ID of the row.
 * @param cropId - The ID of the crop.
 * @returns A string indicating the rotation status: 'ok', 'warning', or 'blocked'.
 */
export function getRotationStatus(
  plantings: PlantingWithDetails[],
  rowId: number,
  cropId: number,
): 'ok' | 'warning' | 'blocked' {
  const history = getRotationHistoryForRow(plantings, rowId);
  const lastIndexOfCrop = history.map(c => c.id).lastIndexOf(cropId);

  if (lastIndexOfCrop === -1) {
    return 'ok';
  }

  const subsequentCrops = history.slice(lastIndexOfCrop + 1);
  const uniqueSubsequentCrops = new Map<number, CropInfo>();
  subsequentCrops.forEach(crop => {
    if (!uniqueSubsequentCrops.has(crop.id)) {
      uniqueSubsequentCrops.set(crop.id, crop);
    }
  });

  if (uniqueSubsequentCrops.size < 3) {
    return 'blocked';
  }
  if (uniqueSubsequentCrops.size === 3) {
    return 'warning'; // It's now allowed, but was recently blocked.
  }

  return 'ok';
}