import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getPerennialPlots } from '../endpoints/perennial-plots_GET.schema';
import { postPerennialPlot, type InputType as PostPerennialPlotInput } from '../endpoints/perennial-plots_POST.schema';
import { getPerennialHarvests } from '../endpoints/perennial-harvests_GET.schema';
import { postPerennialHarvest, type InputType as PostPerennialHarvestInput } from '../endpoints/perennial-harvests_POST.schema';

export const perennialQueryKeys = {
  plots: ['perennialPlots'] as const,
  harvests: ['perennialHarvests'] as const,
};

// Query for fetching all perennial plots
export const useGetPerennialPlots = () => {
  return useQuery({
    queryKey: perennialQueryKeys.plots,
    queryFn: () => getPerennialPlots(),
  });
};

// Mutation for creating a new perennial plot
export const usePostPerennialPlot = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newPlot: PostPerennialPlotInput) => postPerennialPlot(newPlot),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: perennialQueryKeys.plots });
    },
  });
};

// Query for fetching all perennial harvests
export const useGetPerennialHarvests = () => {
  return useQuery({
    queryKey: perennialQueryKeys.harvests,
    queryFn: () => getPerennialHarvests(),
  });
};

// Mutation for creating a new perennial harvest
export const usePostPerennialHarvest = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newHarvest: PostPerennialHarvestInput) => postPerennialHarvest(newHarvest),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: perennialQueryKeys.harvests });
    },
  });
};