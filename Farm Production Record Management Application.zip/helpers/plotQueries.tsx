import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getPlots } from '../endpoints/plots_GET.schema';
import { postPlot, type InputType as PostPlotInput } from '../endpoints/plots_POST.schema';
import { postPlotsUpdate, type InputType as UpdatePlotInput } from '../endpoints/plots/update_POST.schema';
import { postPlotsDelete, type InputType as DeletePlotInput } from '../endpoints/plots/delete_POST.schema';
import { postPlotsAssignRows, type InputType as AssignRowsInput } from '../endpoints/plots/assign-rows_POST.schema';
import { farmQueryKeys } from './farmQueries';

export const plotQueryKeys = {
  plots: ['plots'] as const,
};

export const useGetPlots = () => {
  return useQuery({
    queryKey: plotQueryKeys.plots,
    queryFn: getPlots,
  });
};

export const usePostPlot = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newPlot: PostPlotInput) => postPlot(newPlot),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: plotQueryKeys.plots });
    },
  });
};

export const useUpdatePlot = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (updatedPlot: UpdatePlotInput) => postPlotsUpdate(updatedPlot),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: plotQueryKeys.plots });
    },
  });
};

export const useDeletePlot = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (plotToDelete: DeletePlotInput) => postPlotsDelete(plotToDelete),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: plotQueryKeys.plots });
    },
  });
};

export const useAssignRowsToPlot = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (assignment: AssignRowsInput) => postPlotsAssignRows(assignment),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: plotQueryKeys.plots });
      // Also invalidate rows query as their plot assignment might be displayed elsewhere
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.rows });
    },
  });
};