import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getFarmSettings } from '../endpoints/farm-settings_GET.schema';
import { postFarmSettings, type InputType as PostFarmSettingsInput } from '../endpoints/farm-settings_POST.schema';

export const farmSettingsQueryKeys = {
  all: ['farmSettings'] as const,
};

export const useGetFarmSettings = () => {
  return useQuery({
    queryKey: farmSettingsQueryKeys.all,
    queryFn: () => getFarmSettings(),
  });
};

export const usePostFarmSettings = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (settings: PostFarmSettingsInput) => postFarmSettings(settings),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: farmSettingsQueryKeys.all });
    },
  });
};