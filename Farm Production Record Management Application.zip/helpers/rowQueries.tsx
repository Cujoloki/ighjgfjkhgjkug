import { useMutation, useQueryClient } from '@tanstack/react-query';
import { postRows, type InputType as PostRowsInput } from '../endpoints/rows_POST.schema';
import { postRowsUpdate, type InputType as UpdateRowInput } from '../endpoints/rows/update_POST.schema';
import { postRowsDelete, type InputType as DeleteRowInput } from '../endpoints/rows/delete_POST.schema';
import { farmQueryKeys } from './farmQueries';

// Mutation for creating new farm rows (single or batch)
export const usePostRows = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newRows: PostRowsInput) => postRows(newRows),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.rows });
    },
  });
};

// Mutation for updating an existing farm row
export const useUpdateRow = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (updatedRow: UpdateRowInput) => postRowsUpdate(updatedRow),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.rows });
    },
  });
};

// Mutation for deleting a farm row
export const useDeleteRow = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (rowToDelete: DeleteRowInput) => postRowsDelete(rowToDelete),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.rows });
    },
  });
};