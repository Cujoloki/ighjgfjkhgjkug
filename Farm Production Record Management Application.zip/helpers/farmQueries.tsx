import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getRows } from '../endpoints/rows_GET.schema';
import { getCrops } from '../endpoints/crops_GET.schema';
import { getPlantings } from '../endpoints/plantings_GET.schema';
import { postPlantings, type InputType as PostPlantingInput } from '../endpoints/plantings_POST.schema';
import { getHarvests } from '../endpoints/harvests_GET.schema';
import { postHarvests, type InputType as PostHarvestInput } from '../endpoints/harvests_POST.schema';

export const farmQueryKeys = {
  rows: ['rows'] as const,
  crops: ['crops'] as const,
  plantings: ['plantings'] as const,
  harvests: ['harvests'] as const,
};

// Query for fetching all farm rows with current plantings
export const useGetRows = () => {
  return useQuery({
    queryKey: farmQueryKeys.rows,
    queryFn: () => getRows(),
  });
};

// Query for fetching all available crops
export const useGetCrops = () => {
  return useQuery({
    queryKey: farmQueryKeys.crops,
    queryFn: () => getCrops(),
  });
};

// Query for fetching all plantings
export const useGetPlantings = () => {
  return useQuery({
    queryKey: farmQueryKeys.plantings,
    queryFn: () => getPlantings(),
  });
};

// Mutation for creating a new planting
export const usePostPlanting = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newPlanting: PostPlantingInput) => postPlantings(newPlanting),
    onSuccess: () => {
      // When a new planting is created, the state of rows and the list of plantings have changed.
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.rows });
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.plantings });
    },
  });
};

// Query for fetching all harvests
export const useGetHarvests = () => {
  return useQuery({
    queryKey: farmQueryKeys.harvests,
    queryFn: () => getHarvests(),
  });
};

// Mutation for creating a new harvest
export const usePostHarvest = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newHarvest: PostHarvestInput) => postHarvests(newHarvest),
    onSuccess: () => {
      // A new harvest record means the list of harvests should be refetched.
      queryClient.invalidateQueries({ queryKey: farmQueryKeys.harvests });
    },
  });
};